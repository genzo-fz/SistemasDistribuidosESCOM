(function(){/*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
'use strict';var m;function aa(a){var b=0;return function(){return b<a.length?{done:!1,value:a[b++]}:{done:!0}}}
var ba="function"==typeof Object.defineProperties?Object.defineProperty:function(a,b,c){if(a==Array.prototype||a==Object.prototype)return a;a[b]=c.value;return a};
function ca(a){a=["object"==typeof globalThis&&globalThis,a,"object"==typeof window&&window,"object"==typeof self&&self,"object"==typeof global&&global];for(var b=0;b<a.length;++b){var c=a[b];if(c&&c.Math==Math)return c}throw Error("Cannot find global object");}
var da=ca(this);function t(a,b){if(b)a:{var c=da;a=a.split(".");for(var d=0;d<a.length-1;d++){var e=a[d];if(!(e in c))break a;c=c[e]}a=a[a.length-1];d=c[a];b=b(d);b!=d&&null!=b&&ba(c,a,{configurable:!0,writable:!0,value:b})}}
t("Symbol",function(a){function b(f){if(this instanceof b)throw new TypeError("Symbol is not a constructor");return new c(d+(f||"")+"_"+e++,f)}
function c(f,g){this.h=f;ba(this,"description",{configurable:!0,writable:!0,value:g})}
if(a)return a;c.prototype.toString=function(){return this.h};
var d="jscomp_symbol_"+(1E9*Math.random()>>>0)+"_",e=0;return b});
t("Symbol.iterator",function(a){if(a)return a;a=Symbol("Symbol.iterator");for(var b="Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "),c=0;c<b.length;c++){var d=da[b[c]];"function"===typeof d&&"function"!=typeof d.prototype[a]&&ba(d.prototype,a,{configurable:!0,writable:!0,value:function(){return ea(aa(this))}})}return a});
function ea(a){a={next:a};a[Symbol.iterator]=function(){return this};
return a}
function u(a){var b="undefined"!=typeof Symbol&&Symbol.iterator&&a[Symbol.iterator];return b?b.call(a):{next:aa(a)}}
var fa="function"==typeof Object.create?Object.create:function(a){function b(){}
b.prototype=a;return new b},ha;
if("function"==typeof Object.setPrototypeOf)ha=Object.setPrototypeOf;else{var ia;a:{var ja={a:!0},ka={};try{ka.__proto__=ja;ia=ka.a;break a}catch(a){}ia=!1}ha=ia?function(a,b){a.__proto__=b;if(a.__proto__!==b)throw new TypeError(a+" is not extensible");return a}:null}var la=ha;
function v(a,b){a.prototype=fa(b.prototype);a.prototype.constructor=a;if(la)la(a,b);else for(var c in b)if("prototype"!=c)if(Object.defineProperties){var d=Object.getOwnPropertyDescriptor(b,c);d&&Object.defineProperty(a,c,d)}else a[c]=b[c];a.G=b.prototype}
function ma(){this.o=!1;this.l=null;this.i=void 0;this.h=1;this.m=this.u=0;this.B=this.j=null}
function na(a){if(a.o)throw new TypeError("Generator is already running");a.o=!0}
ma.prototype.v=function(a){this.i=a};
function oa(a,b){a.j={ma:b,pa:!0};a.h=a.u||a.m}
ma.prototype.return=function(a){this.j={return:a};this.h=this.m};
function x(a,b,c){a.h=c;return{value:b}}
ma.prototype.s=function(a){this.h=a};
function pa(a,b,c){a.u=b;void 0!=c&&(a.m=c)}
function qa(a){a.u=0;var b=a.j.ma;a.j=null;return b}
function ra(a){a.B=[a.j];a.u=0;a.m=0}
function sa(a){var b=a.B.splice(0)[0];(b=a.j=a.j||b)?b.pa?a.h=a.u||a.m:void 0!=b.s&&a.m<b.s?(a.h=b.s,a.j=null):a.h=a.m:a.h=0}
function ta(a){this.h=new ma;this.i=a}
function ua(a,b){na(a.h);var c=a.h.l;if(c)return va(a,"return"in c?c["return"]:function(d){return{value:d,done:!0}},b,a.h.return);
a.h.return(b);return wa(a)}
function va(a,b,c,d){try{var e=b.call(a.h.l,c);if(!(e instanceof Object))throw new TypeError("Iterator result "+e+" is not an object");if(!e.done)return a.h.o=!1,e;var f=e.value}catch(g){return a.h.l=null,oa(a.h,g),wa(a)}a.h.l=null;d.call(a.h,f);return wa(a)}
function wa(a){for(;a.h.h;)try{var b=a.i(a.h);if(b)return a.h.o=!1,{value:b.value,done:!1}}catch(c){a.h.i=void 0,oa(a.h,c)}a.h.o=!1;if(a.h.j){b=a.h.j;a.h.j=null;if(b.pa)throw b.ma;return{value:b.return,done:!0}}return{value:void 0,done:!0}}
function xa(a){this.next=function(b){na(a.h);a.h.l?b=va(a,a.h.l.next,b,a.h.v):(a.h.v(b),b=wa(a));return b};
this.throw=function(b){na(a.h);a.h.l?b=va(a,a.h.l["throw"],b,a.h.v):(oa(a.h,b),b=wa(a));return b};
this.return=function(b){return ua(a,b)};
this[Symbol.iterator]=function(){return this}}
function y(a,b){b=new xa(new ta(b));la&&a.prototype&&la(b,a.prototype);return b}
t("Reflect.setPrototypeOf",function(a){return a?a:la?function(b,c){try{return la(b,c),!0}catch(d){return!1}}:null});
function za(a,b){return Object.prototype.hasOwnProperty.call(a,b)}
t("WeakMap",function(a){function b(k){this.h=(h+=Math.random()+1).toString();if(k){k=u(k);for(var l;!(l=k.next()).done;)l=l.value,this.set(l[0],l[1])}}
function c(){}
function d(k){var l=typeof k;return"object"===l&&null!==k||"function"===l}
function e(k){if(!za(k,g)){var l=new c;ba(k,g,{value:l})}}
function f(k){var l=Object[k];l&&(Object[k]=function(n){if(n instanceof c)return n;Object.isExtensible(n)&&e(n);return l(n)})}
if(function(){if(!a||!Object.seal)return!1;try{var k=Object.seal({}),l=Object.seal({}),n=new a([[k,2],[l,3]]);if(2!=n.get(k)||3!=n.get(l))return!1;n.delete(k);n.set(l,4);return!n.has(k)&&4==n.get(l)}catch(p){return!1}}())return a;
var g="$jscomp_hidden_"+Math.random();f("freeze");f("preventExtensions");f("seal");var h=0;b.prototype.set=function(k,l){if(!d(k))throw Error("Invalid WeakMap key");e(k);if(!za(k,g))throw Error("WeakMap key fail: "+k);k[g][this.h]=l;return this};
b.prototype.get=function(k){return d(k)&&za(k,g)?k[g][this.h]:void 0};
b.prototype.has=function(k){return d(k)&&za(k,g)&&za(k[g],this.h)};
b.prototype.delete=function(k){return d(k)&&za(k,g)&&za(k[g],this.h)?delete k[g][this.h]:!1};
return b});
t("Map",function(a){function b(){var h={};return h.previous=h.next=h.head=h}
function c(h,k){var l=h.h;return ea(function(){if(l){for(;l.head!=h.h;)l=l.previous;for(;l.next!=l.head;)return l=l.next,{done:!1,value:k(l)};l=null}return{done:!0,value:void 0}})}
function d(h,k){var l=k&&typeof k;"object"==l||"function"==l?f.has(k)?l=f.get(k):(l=""+ ++g,f.set(k,l)):l="p_"+k;var n=h.data_[l];if(n&&za(h.data_,l))for(h=0;h<n.length;h++){var p=n[h];if(k!==k&&p.key!==p.key||k===p.key)return{id:l,list:n,index:h,A:p}}return{id:l,list:n,index:-1,A:void 0}}
function e(h){this.data_={};this.h=b();this.size=0;if(h){h=u(h);for(var k;!(k=h.next()).done;)k=k.value,this.set(k[0],k[1])}}
if(function(){if(!a||"function"!=typeof a||!a.prototype.entries||"function"!=typeof Object.seal)return!1;try{var h=Object.seal({x:4}),k=new a(u([[h,"s"]]));if("s"!=k.get(h)||1!=k.size||k.get({x:4})||k.set({x:4},"t")!=k||2!=k.size)return!1;var l=k.entries(),n=l.next();if(n.done||n.value[0]!=h||"s"!=n.value[1])return!1;n=l.next();return n.done||4!=n.value[0].x||"t"!=n.value[1]||!l.next().done?!1:!0}catch(p){return!1}}())return a;
var f=new WeakMap;e.prototype.set=function(h,k){h=0===h?0:h;var l=d(this,h);l.list||(l.list=this.data_[l.id]=[]);l.A?l.A.value=k:(l.A={next:this.h,previous:this.h.previous,head:this.h,key:h,value:k},l.list.push(l.A),this.h.previous.next=l.A,this.h.previous=l.A,this.size++);return this};
e.prototype.delete=function(h){h=d(this,h);return h.A&&h.list?(h.list.splice(h.index,1),h.list.length||delete this.data_[h.id],h.A.previous.next=h.A.next,h.A.next.previous=h.A.previous,h.A.head=null,this.size--,!0):!1};
e.prototype.clear=function(){this.data_={};this.h=this.h.previous=b();this.size=0};
e.prototype.has=function(h){return!!d(this,h).A};
e.prototype.get=function(h){return(h=d(this,h).A)&&h.value};
e.prototype.entries=function(){return c(this,function(h){return[h.key,h.value]})};
e.prototype.keys=function(){return c(this,function(h){return h.key})};
e.prototype.values=function(){return c(this,function(h){return h.value})};
e.prototype.forEach=function(h,k){for(var l=this.entries(),n;!(n=l.next()).done;)n=n.value,h.call(k,n[1],n[0],this)};
e.prototype[Symbol.iterator]=e.prototype.entries;var g=0;return e});
function Aa(a,b,c){if(null==a)throw new TypeError("The 'this' value for String.prototype."+c+" must not be null or undefined");if(b instanceof RegExp)throw new TypeError("First argument to String.prototype."+c+" must not be a regular expression");return a+""}
t("String.prototype.endsWith",function(a){return a?a:function(b,c){var d=Aa(this,b,"endsWith");b+="";void 0===c&&(c=d.length);c=Math.max(0,Math.min(c|0,d.length));for(var e=b.length;0<e&&0<c;)if(d[--c]!=b[--e])return!1;return 0>=e}});
t("Array.prototype.find",function(a){return a?a:function(b,c){a:{var d=this;d instanceof String&&(d=String(d));for(var e=d.length,f=0;f<e;f++){var g=d[f];if(b.call(c,g,f,d)){b=g;break a}}b=void 0}return b}});
t("String.prototype.startsWith",function(a){return a?a:function(b,c){var d=Aa(this,b,"startsWith");b+="";var e=d.length,f=b.length;c=Math.max(0,Math.min(c|0,d.length));for(var g=0;g<f&&c<e;)if(d[c++]!=b[g++])return!1;return g>=f}});
t("Object.setPrototypeOf",function(a){return a||la});
var Ba="function"==typeof Object.assign?Object.assign:function(a,b){for(var c=1;c<arguments.length;c++){var d=arguments[c];if(d)for(var e in d)za(d,e)&&(a[e]=d[e])}return a};
t("Object.assign",function(a){return a||Ba});
t("Promise",function(a){function b(g){this.h=0;this.j=void 0;this.i=[];this.o=!1;var h=this.l();try{g(h.resolve,h.reject)}catch(k){h.reject(k)}}
function c(){this.h=null}
function d(g){return g instanceof b?g:new b(function(h){h(g)})}
if(a)return a;c.prototype.i=function(g){if(null==this.h){this.h=[];var h=this;this.j(function(){h.m()})}this.h.push(g)};
var e=da.setTimeout;c.prototype.j=function(g){e(g,0)};
c.prototype.m=function(){for(;this.h&&this.h.length;){var g=this.h;this.h=[];for(var h=0;h<g.length;++h){var k=g[h];g[h]=null;try{k()}catch(l){this.l(l)}}}this.h=null};
c.prototype.l=function(g){this.j(function(){throw g;})};
b.prototype.l=function(){function g(l){return function(n){k||(k=!0,l.call(h,n))}}
var h=this,k=!1;return{resolve:g(this.U),reject:g(this.m)}};
b.prototype.U=function(g){if(g===this)this.m(new TypeError("A Promise cannot resolve to itself"));else if(g instanceof b)this.fa(g);else{a:switch(typeof g){case "object":var h=null!=g;break a;case "function":h=!0;break a;default:h=!1}h?this.P(g):this.u(g)}};
b.prototype.P=function(g){var h=void 0;try{h=g.then}catch(k){this.m(k);return}"function"==typeof h?this.xa(h,g):this.u(g)};
b.prototype.m=function(g){this.v(2,g)};
b.prototype.u=function(g){this.v(1,g)};
b.prototype.v=function(g,h){if(0!=this.h)throw Error("Cannot settle("+g+", "+h+"): Promise already settled in state"+this.h);this.h=g;this.j=h;2===this.h&&this.V();this.B()};
b.prototype.V=function(){var g=this;e(function(){if(g.M()){var h=da.console;"undefined"!==typeof h&&h.error(g.j)}},1)};
b.prototype.M=function(){if(this.o)return!1;var g=da.CustomEvent,h=da.Event,k=da.dispatchEvent;if("undefined"===typeof k)return!0;"function"===typeof g?g=new g("unhandledrejection",{cancelable:!0}):"function"===typeof h?g=new h("unhandledrejection",{cancelable:!0}):(g=da.document.createEvent("CustomEvent"),g.initCustomEvent("unhandledrejection",!1,!0,g));g.promise=this;g.reason=this.j;return k(g)};
b.prototype.B=function(){if(null!=this.i){for(var g=0;g<this.i.length;++g)f.i(this.i[g]);this.i=null}};
var f=new c;b.prototype.fa=function(g){var h=this.l();g.X(h.resolve,h.reject)};
b.prototype.xa=function(g,h){var k=this.l();try{g.call(h,k.resolve,k.reject)}catch(l){k.reject(l)}};
b.prototype.then=function(g,h){function k(r,q){return"function"==typeof r?function(w){try{l(r(w))}catch(A){n(A)}}:q}
var l,n,p=new b(function(r,q){l=r;n=q});
this.X(k(g,l),k(h,n));return p};
b.prototype.catch=function(g){return this.then(void 0,g)};
b.prototype.X=function(g,h){function k(){switch(l.h){case 1:g(l.j);break;case 2:h(l.j);break;default:throw Error("Unexpected state: "+l.h);}}
var l=this;null==this.i?f.i(k):this.i.push(k);this.o=!0};
b.resolve=d;b.reject=function(g){return new b(function(h,k){k(g)})};
b.race=function(g){return new b(function(h,k){for(var l=u(g),n=l.next();!n.done;n=l.next())d(n.value).X(h,k)})};
b.all=function(g){var h=u(g),k=h.next();return k.done?d([]):new b(function(l,n){function p(w){return function(A){r[w]=A;q--;0==q&&l(r)}}
var r=[],q=0;do r.push(void 0),q++,d(k.value).X(p(r.length-1),n),k=h.next();while(!k.done)})};
return b});
function Ca(a,b){a instanceof String&&(a+="");var c=0,d=!1,e={next:function(){if(!d&&c<a.length){var f=c++;return{value:b(f,a[f]),done:!1}}d=!0;return{done:!0,value:void 0}}};
e[Symbol.iterator]=function(){return e};
return e}
t("Array.prototype.entries",function(a){return a?a:function(){return Ca(this,function(b,c){return[b,c]})}});
t("Object.entries",function(a){return a?a:function(b){var c=[],d;for(d in b)za(b,d)&&c.push([d,b[d]]);return c}});
t("Array.prototype.keys",function(a){return a?a:function(){return Ca(this,function(b){return b})}});
t("Array.prototype.values",function(a){return a?a:function(){return Ca(this,function(b,c){return c})}});
t("Array.from",function(a){return a?a:function(b,c,d){c=null!=c?c:function(h){return h};
var e=[],f="undefined"!=typeof Symbol&&Symbol.iterator&&b[Symbol.iterator];if("function"==typeof f){b=f.call(b);for(var g=0;!(f=b.next()).done;)e.push(c.call(d,f.value,g++))}else for(f=b.length,g=0;g<f;g++)e.push(c.call(d,b[g],g));return e}});
t("Number.isNaN",function(a){return a?a:function(b){return"number"===typeof b&&isNaN(b)}});
t("Number.MAX_SAFE_INTEGER",function(){return 9007199254740991});
t("Object.is",function(a){return a?a:function(b,c){return b===c?0!==b||1/b===1/c:b!==b&&c!==c}});
t("Array.prototype.includes",function(a){return a?a:function(b,c){var d=this;d instanceof String&&(d=String(d));var e=d.length;c=c||0;for(0>c&&(c=Math.max(c+e,0));c<e;c++){var f=d[c];if(f===b||Object.is(f,b))return!0}return!1}});
t("String.prototype.includes",function(a){return a?a:function(b,c){return-1!==Aa(this,b,"includes").indexOf(b,c||0)}});
t("Set",function(a){function b(c){this.h=new Map;if(c){c=u(c);for(var d;!(d=c.next()).done;)this.add(d.value)}this.size=this.h.size}
if(function(){if(!a||"function"!=typeof a||!a.prototype.entries||"function"!=typeof Object.seal)return!1;try{var c=Object.seal({x:4}),d=new a(u([c]));if(!d.has(c)||1!=d.size||d.add(c)!=d||1!=d.size||d.add({x:4})!=d||2!=d.size)return!1;var e=d.entries(),f=e.next();if(f.done||f.value[0]!=c||f.value[1]!=c)return!1;f=e.next();return f.done||f.value[0]==c||4!=f.value[0].x||f.value[1]!=f.value[0]?!1:e.next().done}catch(g){return!1}}())return a;
b.prototype.add=function(c){c=0===c?0:c;this.h.set(c,c);this.size=this.h.size;return this};
b.prototype.delete=function(c){c=this.h.delete(c);this.size=this.h.size;return c};
b.prototype.clear=function(){this.h.clear();this.size=0};
b.prototype.has=function(c){return this.h.has(c)};
b.prototype.entries=function(){return this.h.entries()};
b.prototype.values=function(){return this.h.values()};
b.prototype.keys=b.prototype.values;b.prototype[Symbol.iterator]=b.prototype.values;b.prototype.forEach=function(c,d){var e=this;this.h.forEach(function(f){return c.call(d,f,f,e)})};
return b});
var B=this||self;function C(a,b){a=a.split(".");b=b||B;for(var c=0;c<a.length;c++)if(b=b[a[c]],null==b)return null;return b}
function Da(){}
function Ea(a){var b=typeof a;return"object"!=b?b:a?Array.isArray(a)?"array":b:"null"}
function Fa(a){var b=Ea(a);return"array"==b||"object"==b&&"number"==typeof a.length}
function D(a){var b=typeof a;return"object"==b&&null!=a||"function"==b}
function Ga(a){return Object.prototype.hasOwnProperty.call(a,Ha)&&a[Ha]||(a[Ha]=++Ia)}
var Ha="closure_uid_"+(1E9*Math.random()>>>0),Ia=0;function Ja(a,b,c){return a.call.apply(a.bind,arguments)}
function Ka(a,b,c){if(!a)throw Error();if(2<arguments.length){var d=Array.prototype.slice.call(arguments,2);return function(){var e=Array.prototype.slice.call(arguments);Array.prototype.unshift.apply(e,d);return a.apply(b,e)}}return function(){return a.apply(b,arguments)}}
function La(a,b,c){Function.prototype.bind&&-1!=Function.prototype.bind.toString().indexOf("native code")?La=Ja:La=Ka;return La.apply(null,arguments)}
function E(a,b){a=a.split(".");var c=B;a[0]in c||"undefined"==typeof c.execScript||c.execScript("var "+a[0]);for(var d;a.length&&(d=a.shift());)a.length||void 0===b?c[d]&&c[d]!==Object.prototype[d]?c=c[d]:c=c[d]={}:c[d]=b}
function G(a,b){function c(){}
c.prototype=b.prototype;a.G=b.prototype;a.prototype=new c;a.prototype.constructor=a;a.gb=function(d,e,f){for(var g=Array(arguments.length-2),h=2;h<arguments.length;h++)g[h-2]=arguments[h];return b.prototype[e].apply(d,g)}}
function Ma(a){return a}
;function Na(a,b){if(Error.captureStackTrace)Error.captureStackTrace(this,Na);else{var c=Error().stack;c&&(this.stack=c)}a&&(this.message=String(a));b&&(this.Aa=b)}
G(Na,Error);Na.prototype.name="CustomError";function Oa(a){a=a.url;var b=/[?&]dsh=1(&|$)/.test(a);this.j=!b&&/[?&]ae=1(&|$)/.test(a);this.l=!b&&/[?&]ae=2(&|$)/.test(a);if((this.h=/[?&]adurl=([^&]*)/.exec(a))&&this.h[1]){try{var c=decodeURIComponent(this.h[1])}catch(d){c=null}this.i=c}}
;function Pa(a){var b=!1,c;return function(){b||(c=a(),b=!0);return c}}
;var Qa=Array.prototype.indexOf?function(a,b){return Array.prototype.indexOf.call(a,b,void 0)}:function(a,b){if("string"===typeof a)return"string"!==typeof b||1!=b.length?-1:a.indexOf(b,0);
for(var c=0;c<a.length;c++)if(c in a&&a[c]===b)return c;return-1},H=Array.prototype.forEach?function(a,b,c){Array.prototype.forEach.call(a,b,c)}:function(a,b,c){for(var d=a.length,e="string"===typeof a?a.split(""):a,f=0;f<d;f++)f in e&&b.call(c,e[f],f,a)},Ra=Array.prototype.reduce?function(a,b,c){return Array.prototype.reduce.call(a,b,c)}:function(a,b,c){var d=c;
H(a,function(e,f){d=b.call(void 0,d,e,f,a)});
return d};
function Sa(a,b){b=Qa(a,b);var c;(c=0<=b)&&Array.prototype.splice.call(a,b,1);return c}
function Ta(a){return Array.prototype.concat.apply([],arguments)}
function Ua(a){var b=a.length;if(0<b){for(var c=Array(b),d=0;d<b;d++)c[d]=a[d];return c}return[]}
function Va(a,b){for(var c=1;c<arguments.length;c++){var d=arguments[c];if(Fa(d)){var e=a.length||0,f=d.length||0;a.length=e+f;for(var g=0;g<f;g++)a[e+g]=d[g]}else a.push(d)}}
;function Wa(a,b){for(var c in a)b.call(void 0,a[c],c,a)}
function Xa(a){var b=Ya,c;for(c in b)if(a.call(void 0,b[c],c,b))return c}
function Za(a,b){for(var c in a)if(!(c in b)||a[c]!==b[c])return!1;for(var d in b)if(!(d in a))return!1;return!0}
function $a(a){if(!a||"object"!==typeof a)return a;if("function"===typeof a.clone)return a.clone();if("undefined"!==typeof Map&&a instanceof Map)return new Map(a);if("undefined"!==typeof Set&&a instanceof Set)return new Set(a);var b=Array.isArray(a)?[]:"function"!==typeof ArrayBuffer||"function"!==typeof ArrayBuffer.isView||!ArrayBuffer.isView(a)||a instanceof DataView?{}:new a.constructor(a.length),c;for(c in a)b[c]=$a(a[c]);return b}
var ab="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function bb(a,b){for(var c,d,e=1;e<arguments.length;e++){d=arguments[e];for(c in d)a[c]=d[c];for(var f=0;f<ab.length;f++)c=ab[f],Object.prototype.hasOwnProperty.call(d,c)&&(a[c]=d[c])}}
;var cb;var db=String.prototype.trim?function(a){return a.trim()}:function(a){return/^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]};
function eb(a,b){if(b)a=a.replace(fb,"&amp;").replace(gb,"&lt;").replace(hb,"&gt;").replace(ib,"&quot;").replace(jb,"&#39;").replace(kb,"&#0;");else{if(!lb.test(a))return a;-1!=a.indexOf("&")&&(a=a.replace(fb,"&amp;"));-1!=a.indexOf("<")&&(a=a.replace(gb,"&lt;"));-1!=a.indexOf(">")&&(a=a.replace(hb,"&gt;"));-1!=a.indexOf('"')&&(a=a.replace(ib,"&quot;"));-1!=a.indexOf("'")&&(a=a.replace(jb,"&#39;"));-1!=a.indexOf("\x00")&&(a=a.replace(kb,"&#0;"))}return a}
var fb=/&/g,gb=/</g,hb=/>/g,ib=/"/g,jb=/'/g,kb=/\x00/g,lb=/[\x00&<>"']/;function mb(a,b){this.h=b===nb?a:""}
m=mb.prototype;m.ca=!0;m.Z=function(){return this.h.toString()};
m.oa=!0;m.na=function(){return 1};
m.toString=function(){return this.h.toString()};
var ob=/^(?:audio\/(?:3gpp2|3gpp|aac|L16|midi|mp3|mp4|mpeg|oga|ogg|opus|x-m4a|x-matroska|x-wav|wav|webm)|font\/\w+|image\/(?:bmp|gif|jpeg|jpg|png|tiff|webp|x-icon)|video\/(?:mpeg|mp4|ogg|webm|quicktime|x-matroska))(?:;\w+=(?:\w+|"[\w;,= ]+"))*$/i,pb=/^data:(.*);base64,[a-z0-9+\/]+=*$/i,qb=/^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i,nb={},rb=new mb("about:invalid#zClosurez",nb);var sb;a:{var tb=B.navigator;if(tb){var ub=tb.userAgent;if(ub){sb=ub;break a}}sb=""}function I(a){return-1!=sb.indexOf(a)}
;function vb(a,b,c){this.h=c===wb?a:"";this.i=b}
m=vb.prototype;m.oa=!0;m.na=function(){return this.i};
m.ca=!0;m.Z=function(){return this.h.toString()};
m.toString=function(){return this.h.toString()};
var wb={};function xb(a,b){if(void 0===cb){var c=null;var d=B.trustedTypes;if(d&&d.createPolicy){try{c=d.createPolicy("goog#html",{createHTML:Ma,createScript:Ma,createScriptURL:Ma})}catch(e){B.console&&B.console.error(e.message)}cb=c}else cb=c}a=(c=cb)?c.createHTML(a):a;return new vb(a,b,wb)}
;function yb(a){return a=eb(a,void 0)}
;var zb=/^(?:([^:/?#.]+):)?(?:\/\/(?:([^\\/?#]*)@)?([^\\/?#]*?)(?::([0-9]+))?(?=[\\/?#]|$))?([^?#]+)?(?:\?([^#]*))?(?:#([\s\S]*))?$/;function Ab(a){return a?decodeURI(a):a}
function Bb(a){return Ab(a.match(zb)[3]||null)}
function Cb(a){var b=a.match(zb);a=b[1];var c=b[2],d=b[3];b=b[4];var e="";a&&(e+=a+":");d&&(e+="//",c&&(e+=c+"@"),e+=d,b&&(e+=":"+b));return e}
function Db(a,b,c){if(Array.isArray(b))for(var d=0;d<b.length;d++)Db(a,String(b[d]),c);else null!=b&&c.push(a+(""===b?"":"="+encodeURIComponent(String(b))))}
function Eb(a){var b=[],c;for(c in a)Db(c,a[c],b);return b.join("&")}
var Fb=/#|$/;function Gb(a,b){var c=a.search(Fb);a:{var d=0;for(var e=b.length;0<=(d=a.indexOf(b,d))&&d<c;){var f=a.charCodeAt(d-1);if(38==f||63==f)if(f=a.charCodeAt(d+e),!f||61==f||38==f||35==f)break a;d+=e+1}d=-1}if(0>d)return null;e=a.indexOf("&",d);if(0>e||e>c)e=c;d+=b.length+1;return decodeURIComponent(a.substr(d,e-d).replace(/\+/g," "))}
;function J(a,b){var c=void 0;return new (c||(c=Promise))(function(d,e){function f(k){try{h(b.next(k))}catch(l){e(l)}}
function g(k){try{h(b["throw"](k))}catch(l){e(l)}}
function h(k){k.done?d(k.value):(new c(function(l){l(k.value)})).then(f,g)}
h((b=b.apply(a,void 0)).next())})}
;function Hb(){return I("iPhone")&&!I("iPod")&&!I("iPad")}
;function Ib(a){Ib[" "](a);return a}
Ib[" "]=Da;var Jb=I("Opera"),Kb=I("Trident")||I("MSIE"),Lb=I("Edge"),Mb=I("Gecko")&&!(-1!=sb.toLowerCase().indexOf("webkit")&&!I("Edge"))&&!(I("Trident")||I("MSIE"))&&!I("Edge"),Nb=-1!=sb.toLowerCase().indexOf("webkit")&&!I("Edge");function Ob(){var a=B.document;return a?a.documentMode:void 0}
var Pb;a:{var Qb="",Rb=function(){var a=sb;if(Mb)return/rv:([^\);]+)(\)|;)/.exec(a);if(Lb)return/Edge\/([\d\.]+)/.exec(a);if(Kb)return/\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);if(Nb)return/WebKit\/(\S+)/.exec(a);if(Jb)return/(?:Version)[ \/]?(\S+)/.exec(a)}();
Rb&&(Qb=Rb?Rb[1]:"");if(Kb){var Sb=Ob();if(null!=Sb&&Sb>parseFloat(Qb)){Pb=String(Sb);break a}}Pb=Qb}var Tb=Pb,Ub;if(B.document&&Kb){var Vb=Ob();Ub=Vb?Vb:parseInt(Tb,10)||void 0}else Ub=void 0;var Wb=Ub;var Xb=Hb()||I("iPod"),Yb=I("iPad"),Zb=I("Safari")&&!((I("Chrome")||I("CriOS"))&&!I("Edge")||I("Coast")||I("Opera")||I("Edge")||I("Edg/")||I("OPR")||I("Firefox")||I("FxiOS")||I("Silk")||I("Android"))&&!(Hb()||I("iPad")||I("iPod"));var $b={},ac=null;var bc={ib:{value:!0,configurable:!0}};var cc=Object,dc=cc.freeze,ec=[];Array.isArray(ec)&&!Object.isFrozen(ec)&&Object.defineProperties(ec,bc);dc.call(cc,ec);var K=window;var fc=!Kb||9<=Number(Wb);function gc(a,b){this.width=a;this.height=b}
m=gc.prototype;m.clone=function(){return new gc(this.width,this.height)};
m.aspectRatio=function(){return this.width/this.height};
m.isEmpty=function(){return!(this.width*this.height)};
m.ceil=function(){this.width=Math.ceil(this.width);this.height=Math.ceil(this.height);return this};
m.floor=function(){this.width=Math.floor(this.width);this.height=Math.floor(this.height);return this};
m.round=function(){this.width=Math.round(this.width);this.height=Math.round(this.height);return this};function hc(a,b){Wa(b,function(c,d){c&&"object"==typeof c&&c.ca&&(c=c.Z());"style"==d?a.style.cssText=c:"class"==d?a.className=c:"for"==d?a.htmlFor=c:ic.hasOwnProperty(d)?a.setAttribute(ic[d],c):0==d.lastIndexOf("aria-",0)||0==d.lastIndexOf("data-",0)?a.setAttribute(d,c):a[d]=c})}
var ic={cellpadding:"cellPadding",cellspacing:"cellSpacing",colspan:"colSpan",frameborder:"frameBorder",height:"height",maxlength:"maxLength",nonce:"nonce",role:"role",rowspan:"rowSpan",type:"type",usemap:"useMap",valign:"vAlign",width:"width"};
function jc(a,b,c){var d=arguments,e=document,f=String(d[0]),g=d[1];if(!fc&&g&&(g.name||g.type)){f=["<",f];g.name&&f.push(' name="',yb(g.name),'"');if(g.type){f.push(' type="',yb(g.type),'"');var h={};bb(h,g);delete h.type;g=h}f.push(">");f=f.join("")}f=kc(e,f);g&&("string"===typeof g?f.className=g:Array.isArray(g)?f.className=g.join(" "):hc(f,g));2<d.length&&lc(e,f,d);return f}
function lc(a,b,c){function d(h){h&&b.appendChild("string"===typeof h?a.createTextNode(h):h)}
for(var e=2;e<c.length;e++){var f=c[e];if(!Fa(f)||D(f)&&0<f.nodeType)d(f);else{a:{if(f&&"number"==typeof f.length){if(D(f)){var g="function"==typeof f.item||"string"==typeof f.item;break a}if("function"===typeof f){g="function"==typeof f.item;break a}}g=!1}H(g?Ua(f):f,d)}}}
function kc(a,b){b=String(b);"application/xhtml+xml"===a.contentType&&(b=b.toLowerCase());return a.createElement(b)}
function mc(a,b){for(var c=0;a;){if(b(a))return a;a=a.parentNode;c++}return null}
;function nc(a){var b=oc;if(b)for(var c in b)Object.prototype.hasOwnProperty.call(b,c)&&a.call(void 0,b[c],c,b)}
function pc(){var a=[];nc(function(b){a.push(b)});
return a}
var oc={Ra:"allow-forms",Sa:"allow-modals",Ta:"allow-orientation-lock",Ua:"allow-pointer-lock",Va:"allow-popups",Wa:"allow-popups-to-escape-sandbox",Xa:"allow-presentation",Ya:"allow-same-origin",Za:"allow-scripts",ab:"allow-top-navigation",bb:"allow-top-navigation-by-user-activation"},qc=Pa(function(){return pc()});
function rc(){var a=kc(document,"IFRAME"),b={};H(qc(),function(c){a.sandbox&&a.sandbox.supports&&a.sandbox.supports(c)&&(b[c]=!0)});
return b}
;var sc=(new Date).getTime();function tc(a){if(!a)return"";a=a.split("#")[0].split("?")[0];a=a.toLowerCase();0==a.indexOf("//")&&(a=window.location.protocol+a);/^[\w\-]*:\/\//.test(a)||(a=window.location.href);var b=a.substring(a.indexOf("://")+3),c=b.indexOf("/");-1!=c&&(b=b.substring(0,c));c=a.substring(0,a.indexOf("://"));if(!c)throw Error("URI is missing protocol: "+a);if("http"!==c&&"https"!==c&&"chrome-extension"!==c&&"moz-extension"!==c&&"file"!==c&&"android-app"!==c&&"chrome-search"!==c&&"chrome-untrusted"!==c&&"chrome"!==
c&&"app"!==c&&"devtools"!==c)throw Error("Invalid URI scheme in origin: "+c);a="";var d=b.indexOf(":");if(-1!=d){var e=b.substring(d+1);b=b.substring(0,d);if("http"===c&&"80"!==e||"https"===c&&"443"!==e)a=":"+e}return c+"://"+b+a}
;function uc(){function a(){e[0]=1732584193;e[1]=4023233417;e[2]=2562383102;e[3]=271733878;e[4]=3285377520;n=l=0}
function b(p){for(var r=g,q=0;64>q;q+=4)r[q/4]=p[q]<<24|p[q+1]<<16|p[q+2]<<8|p[q+3];for(q=16;80>q;q++)p=r[q-3]^r[q-8]^r[q-14]^r[q-16],r[q]=(p<<1|p>>>31)&4294967295;p=e[0];var w=e[1],A=e[2],z=e[3],Q=e[4];for(q=0;80>q;q++){if(40>q)if(20>q){var R=z^w&(A^z);var F=1518500249}else R=w^A^z,F=1859775393;else 60>q?(R=w&A|z&(w|A),F=2400959708):(R=w^A^z,F=3395469782);R=((p<<5|p>>>27)&4294967295)+R+Q+F+r[q]&4294967295;Q=z;z=A;A=(w<<30|w>>>2)&4294967295;w=p;p=R}e[0]=e[0]+p&4294967295;e[1]=e[1]+w&4294967295;e[2]=
e[2]+A&4294967295;e[3]=e[3]+z&4294967295;e[4]=e[4]+Q&4294967295}
function c(p,r){if("string"===typeof p){p=unescape(encodeURIComponent(p));for(var q=[],w=0,A=p.length;w<A;++w)q.push(p.charCodeAt(w));p=q}r||(r=p.length);q=0;if(0==l)for(;q+64<r;)b(p.slice(q,q+64)),q+=64,n+=64;for(;q<r;)if(f[l++]=p[q++],n++,64==l)for(l=0,b(f);q+64<r;)b(p.slice(q,q+64)),q+=64,n+=64}
function d(){var p=[],r=8*n;56>l?c(h,56-l):c(h,64-(l-56));for(var q=63;56<=q;q--)f[q]=r&255,r>>>=8;b(f);for(q=r=0;5>q;q++)for(var w=24;0<=w;w-=8)p[r++]=e[q]>>w&255;return p}
for(var e=[],f=[],g=[],h=[128],k=1;64>k;++k)h[k]=0;var l,n;a();return{reset:a,update:c,digest:d,Ba:function(){for(var p=d(),r="",q=0;q<p.length;q++)r+="0123456789ABCDEF".charAt(Math.floor(p[q]/16))+"0123456789ABCDEF".charAt(p[q]%16);return r}}}
;function vc(a,b,c){var d=String(B.location.href);return d&&a&&b?[b,wc(tc(d),a,c||null)].join(" "):null}
function wc(a,b,c){var d=[],e=[];if(1==(Array.isArray(c)?2:1))return e=[b,a],H(d,function(h){e.push(h)}),xc(e.join(" "));
var f=[],g=[];H(c,function(h){g.push(h.key);f.push(h.value)});
c=Math.floor((new Date).getTime()/1E3);e=0==f.length?[c,b,a]:[f.join(":"),c,b,a];H(d,function(h){e.push(h)});
a=xc(e.join(" "));a=[c,a];0==g.length||a.push(g.join(""));return a.join("_")}
function xc(a){var b=uc();b.update(a);return b.Ba().toLowerCase()}
;var yc={};function zc(a){this.h=a||{cookie:""}}
m=zc.prototype;m.isEnabled=function(){if(!B.navigator.cookieEnabled)return!1;if(!this.isEmpty())return!0;this.set("TESTCOOKIESENABLED","1",{ga:60});if("1"!==this.get("TESTCOOKIESENABLED"))return!1;this.remove("TESTCOOKIESENABLED");return!0};
m.set=function(a,b,c){var d=!1;if("object"===typeof c){var e=c.lb;d=c.secure||!1;var f=c.domain||void 0;var g=c.path||void 0;var h=c.ga}if(/[;=\s]/.test(a))throw Error('Invalid cookie name "'+a+'"');if(/[;\r\n]/.test(b))throw Error('Invalid cookie value "'+b+'"');void 0===h&&(h=-1);this.h.cookie=a+"="+b+(f?";domain="+f:"")+(g?";path="+g:"")+(0>h?"":0==h?";expires="+(new Date(1970,1,1)).toUTCString():";expires="+(new Date(Date.now()+1E3*h)).toUTCString())+(d?";secure":"")+(null!=e?";samesite="+e:"")};
m.get=function(a,b){for(var c=a+"=",d=(this.h.cookie||"").split(";"),e=0,f;e<d.length;e++){f=db(d[e]);if(0==f.lastIndexOf(c,0))return f.substr(c.length);if(f==a)return""}return b};
m.remove=function(a,b,c){var d=void 0!==this.get(a);this.set(a,"",{ga:0,path:b,domain:c});return d};
m.isEmpty=function(){return!this.h.cookie};
m.clear=function(){for(var a=(this.h.cookie||"").split(";"),b=[],c=[],d,e,f=0;f<a.length;f++)e=db(a[f]),d=e.indexOf("="),-1==d?(b.push(""),c.push(e)):(b.push(e.substring(0,d)),c.push(e.substring(d+1)));for(a=b.length-1;0<=a;a--)this.remove(b[a])};
var Ac=new zc("undefined"==typeof document?null:document);function Bc(a){return!!yc.FPA_SAMESITE_PHASE2_MOD||!(void 0===a||!a)}
function Cc(a,b,c,d){(a=B[a])||(a=(new zc(document)).get(b));return a?vc(a,c,d):null}
function Dc(a){var b=void 0===b?!1:b;var c=tc(String(B.location.href)),d=[];var e=b;e=void 0===e?!1:e;var f=B.__SAPISID||B.__APISID||B.__3PSAPISID||B.__OVERRIDE_SID;Bc(e)&&(f=f||B.__1PSAPISID);if(f)e=!0;else{var g=new zc(document);f=g.get("SAPISID")||g.get("APISID")||g.get("__Secure-3PAPISID")||g.get("SID");Bc(e)&&(f=f||g.get("__Secure-1PAPISID"));e=!!f}e&&(e=(c=0==c.indexOf("https:")||0==c.indexOf("chrome-extension:")||0==c.indexOf("moz-extension:"))?B.__SAPISID:B.__APISID,e||(e=new zc(document),
e=e.get(c?"SAPISID":"APISID")||e.get("__Secure-3PAPISID")),(e=e?vc(e,c?"SAPISIDHASH":"APISIDHASH",a):null)&&d.push(e),c&&Bc(b)&&((b=Cc("__1PSAPISID","__Secure-1PAPISID","SAPISID1PHASH",a))&&d.push(b),(a=Cc("__3PSAPISID","__Secure-3PAPISID","SAPISID3PHASH",a))&&d.push(a)));return 0==d.length?null:d.join(" ")}
;function Ec(){this.data_=[];this.h=-1}
Ec.prototype.set=function(a,b){b=void 0===b?!0:b;0<=a&&52>a&&0===a%1&&this.data_[a]!=b&&(this.data_[a]=b,this.h=-1)};
Ec.prototype.get=function(a){return!!this.data_[a]};
function Fc(a){-1==a.h&&(a.h=Ra(a.data_,function(b,c,d){return c?b+Math.pow(2,d):b},0));
return a.h}
;function Gc(a,b){this.j=a;this.l=b;this.i=0;this.h=null}
Gc.prototype.get=function(){if(0<this.i){this.i--;var a=this.h;this.h=a.next;a.next=null}else a=this.j();return a};
function Hc(a,b){a.l(b);100>a.i&&(a.i++,b.next=a.h,a.h=b)}
;var Ic;
function Jc(){var a=B.MessageChannel;"undefined"===typeof a&&"undefined"!==typeof window&&window.postMessage&&window.addEventListener&&!I("Presto")&&(a=function(){var e=kc(document,"IFRAME");e.style.display="none";document.documentElement.appendChild(e);var f=e.contentWindow;e=f.document;e.open();e.close();var g="callImmediate"+Math.random(),h="file:"==f.location.protocol?"*":f.location.protocol+"//"+f.location.host;e=La(function(k){if(("*"==h||k.origin==h)&&k.data==g)this.port1.onmessage()},this);
f.addEventListener("message",e,!1);this.port1={};this.port2={postMessage:function(){f.postMessage(g,h)}}});
if("undefined"!==typeof a&&!I("Trident")&&!I("MSIE")){var b=new a,c={},d=c;b.port1.onmessage=function(){if(void 0!==c.next){c=c.next;var e=c.ka;c.ka=null;e()}};
return function(e){d.next={ka:e};d=d.next;b.port2.postMessage(0)}}return function(e){B.setTimeout(e,0)}}
;function Kc(a){B.setTimeout(function(){throw a;},0)}
;function Lc(){this.i=this.h=null}
Lc.prototype.add=function(a,b){var c=Mc.get();c.set(a,b);this.i?this.i.next=c:this.h=c;this.i=c};
Lc.prototype.remove=function(){var a=null;this.h&&(a=this.h,this.h=this.h.next,this.h||(this.i=null),a.next=null);return a};
var Mc=new Gc(function(){return new Nc},function(a){return a.reset()});
function Nc(){this.next=this.scope=this.h=null}
Nc.prototype.set=function(a,b){this.h=a;this.scope=b;this.next=null};
Nc.prototype.reset=function(){this.next=this.scope=this.h=null};function Oc(a,b){Pc||Qc();Rc||(Pc(),Rc=!0);Sc.add(a,b)}
var Pc;function Qc(){if(B.Promise&&B.Promise.resolve){var a=B.Promise.resolve(void 0);Pc=function(){a.then(Tc)}}else Pc=function(){var b=Tc;
"function"!==typeof B.setImmediate||B.Window&&B.Window.prototype&&!I("Edge")&&B.Window.prototype.setImmediate==B.setImmediate?(Ic||(Ic=Jc()),Ic(b)):B.setImmediate(b)}}
var Rc=!1,Sc=new Lc;function Tc(){for(var a;a=Sc.remove();){try{a.h.call(a.scope)}catch(b){Kc(b)}Hc(Mc,a)}Rc=!1}
;function Uc(a,b){this.h=a[B.Symbol.iterator]();this.i=b;this.j=0}
Uc.prototype[Symbol.iterator]=function(){return this};
Uc.prototype.next=function(){var a=this.h.next();return{value:a.done?void 0:this.i.call(void 0,a.value,this.j++),done:a.done}};
function Vc(a,b){return new Uc(a,b)}
;function Wc(){this.blockSize=-1}
;function Xc(){this.blockSize=-1;this.blockSize=64;this.h=[];this.m=[];this.u=[];this.j=[];this.j[0]=128;for(var a=1;a<this.blockSize;++a)this.j[a]=0;this.l=this.i=0;this.reset()}
G(Xc,Wc);Xc.prototype.reset=function(){this.h[0]=1732584193;this.h[1]=4023233417;this.h[2]=2562383102;this.h[3]=271733878;this.h[4]=3285377520;this.l=this.i=0};
function Yc(a,b,c){c||(c=0);var d=a.u;if("string"===typeof b)for(var e=0;16>e;e++)d[e]=b.charCodeAt(c)<<24|b.charCodeAt(c+1)<<16|b.charCodeAt(c+2)<<8|b.charCodeAt(c+3),c+=4;else for(e=0;16>e;e++)d[e]=b[c]<<24|b[c+1]<<16|b[c+2]<<8|b[c+3],c+=4;for(e=16;80>e;e++){var f=d[e-3]^d[e-8]^d[e-14]^d[e-16];d[e]=(f<<1|f>>>31)&4294967295}b=a.h[0];c=a.h[1];var g=a.h[2],h=a.h[3],k=a.h[4];for(e=0;80>e;e++){if(40>e)if(20>e){f=h^c&(g^h);var l=1518500249}else f=c^g^h,l=1859775393;else 60>e?(f=c&g|h&(c|g),l=2400959708):
(f=c^g^h,l=3395469782);f=(b<<5|b>>>27)+f+k+l+d[e]&4294967295;k=h;h=g;g=(c<<30|c>>>2)&4294967295;c=b;b=f}a.h[0]=a.h[0]+b&4294967295;a.h[1]=a.h[1]+c&4294967295;a.h[2]=a.h[2]+g&4294967295;a.h[3]=a.h[3]+h&4294967295;a.h[4]=a.h[4]+k&4294967295}
Xc.prototype.update=function(a,b){if(null!=a){void 0===b&&(b=a.length);for(var c=b-this.blockSize,d=0,e=this.m,f=this.i;d<b;){if(0==f)for(;d<=c;)Yc(this,a,d),d+=this.blockSize;if("string"===typeof a)for(;d<b;){if(e[f]=a.charCodeAt(d),++f,++d,f==this.blockSize){Yc(this,e);f=0;break}}else for(;d<b;)if(e[f]=a[d],++f,++d,f==this.blockSize){Yc(this,e);f=0;break}}this.i=f;this.l+=b}};
Xc.prototype.digest=function(){var a=[],b=8*this.l;56>this.i?this.update(this.j,56-this.i):this.update(this.j,this.blockSize-(this.i-56));for(var c=this.blockSize-1;56<=c;c--)this.m[c]=b&255,b/=256;Yc(this,this.m);for(c=b=0;5>c;c++)for(var d=24;0<=d;d-=8)a[b]=this.h[c]>>d&255,++b;return a};function Zc(a){var b=C("window.location.href");null==a&&(a='Unknown Error of type "null/undefined"');if("string"===typeof a)return{message:a,name:"Unknown error",lineNumber:"Not available",fileName:b,stack:"Not available"};var c=!1;try{var d=a.lineNumber||a.line||"Not available"}catch(g){d="Not available",c=!0}try{var e=a.fileName||a.filename||a.sourceURL||B.$googDebugFname||b}catch(g){e="Not available",c=!0}b=$c(a);if(!(!c&&a.lineNumber&&a.fileName&&a.stack&&a.message&&a.name)){c=a.message;if(null==
c){if(a.constructor&&a.constructor instanceof Function){if(a.constructor.name)c=a.constructor.name;else if(c=a.constructor,ad[c])c=ad[c];else{c=String(c);if(!ad[c]){var f=/function\s+([^\(]+)/m.exec(c);ad[c]=f?f[1]:"[Anonymous]"}c=ad[c]}c='Unknown Error of type "'+c+'"'}else c="Unknown Error of unknown type";"function"===typeof a.toString&&Object.prototype.toString!==a.toString&&(c+=": "+a.toString())}return{message:c,name:a.name||"UnknownError",lineNumber:d,fileName:e,stack:b||"Not available"}}a.stack=
b;return{message:a.message,name:a.name,lineNumber:a.lineNumber,fileName:a.fileName,stack:a.stack}}
function $c(a,b){b||(b={});b[bd(a)]=!0;var c=a.stack||"";(a=a.Aa)&&!b[bd(a)]&&(c+="\nCaused by: ",a.stack&&0==a.stack.indexOf(a.toString())||(c+="string"===typeof a?a:a.message+"\n"),c+=$c(a,b));return c}
function bd(a){var b="";"function"===typeof a.toString&&(b=""+a);return b+a.stack}
var ad={};function cd(){this.m=this.m;this.u=this.u}
cd.prototype.m=!1;cd.prototype.dispose=function(){this.m||(this.m=!0,this.R())};
cd.prototype.R=function(){if(this.u)for(;this.u.length;)this.u.shift()()};var dd="StopIteration"in B?B.StopIteration:{message:"StopIteration",stack:""};function ed(){}
ed.prototype.next=function(){return ed.prototype.h.call(this)};
ed.prototype.h=function(){throw dd;};
ed.prototype.C=function(){return this};function fd(a){if(a instanceof gd||a instanceof hd||a instanceof id)return a;if("function"==typeof a.next)return new gd(function(){return jd(a)});
if("function"==typeof a[Symbol.iterator])return new gd(function(){return a[Symbol.iterator]()});
if("function"==typeof a.C)return new gd(function(){return jd(a.C())});
throw Error("Not an iterator or iterable.");}
function jd(a){if(!(a instanceof ed))return a;var b=!1;return{next:function(){for(var c;!b;)try{c=a.next();break}catch(d){if(d!==dd)throw d;b=!0}return{value:c,done:b}}}}
function gd(a){this.h=a}
gd.prototype.C=function(){return new hd(this.h())};
gd.prototype[Symbol.iterator]=function(){return new id(this.h())};
gd.prototype.i=function(){return new id(this.h())};
function hd(a){this.j=a}
v(hd,ed);hd.prototype.h=function(){var a=this.j.next();if(a.done)throw dd;return a.value};
hd.prototype.next=function(){return hd.prototype.h.call(this)};
hd.prototype[Symbol.iterator]=function(){return new id(this.j)};
hd.prototype.i=function(){return new id(this.j)};
function id(a){gd.call(this,function(){return a});
this.j=a}
v(id,gd);id.prototype.next=function(){return this.j.next()};function kd(a,b){this.i={};this.h=[];this.j=this.size=0;var c=arguments.length;if(1<c){if(c%2)throw Error("Uneven number of arguments");for(var d=0;d<c;d+=2)this.set(arguments[d],arguments[d+1])}else if(a)if(a instanceof kd)for(c=ld(a),d=0;d<c.length;d++)this.set(c[d],a.get(c[d]));else for(d in a)this.set(d,a[d])}
function ld(a){md(a);return a.h.concat()}
m=kd.prototype;m.has=function(a){return nd(this.i,a)};
m.equals=function(a,b){if(this===a)return!0;if(this.size!=a.size)return!1;b=b||od;md(this);for(var c,d=0;c=this.h[d];d++)if(!b(this.get(c),a.get(c)))return!1;return!0};
function od(a,b){return a===b}
m.isEmpty=function(){return 0==this.size};
m.clear=function(){this.i={};this.j=this.size=this.h.length=0};
m.remove=function(a){return this.delete(a)};
m.delete=function(a){return nd(this.i,a)?(delete this.i[a],--this.size,this.j++,this.h.length>2*this.size&&md(this),!0):!1};
function md(a){if(a.size!=a.h.length){for(var b=0,c=0;b<a.h.length;){var d=a.h[b];nd(a.i,d)&&(a.h[c++]=d);b++}a.h.length=c}if(a.size!=a.h.length){var e={};for(c=b=0;b<a.h.length;)d=a.h[b],nd(e,d)||(a.h[c++]=d,e[d]=1),b++;a.h.length=c}}
m.get=function(a,b){return nd(this.i,a)?this.i[a]:b};
m.set=function(a,b){nd(this.i,a)||(this.size+=1,this.h.push(a),this.j++);this.i[a]=b};
m.forEach=function(a,b){for(var c=ld(this),d=0;d<c.length;d++){var e=c[d],f=this.get(e);a.call(b,f,e,this)}};
m.clone=function(){return new kd(this)};
m.keys=function(){return fd(this.C(!0)).i()};
m.values=function(){return fd(this.C(!1)).i()};
m.entries=function(){var a=this;return Vc(this.keys(),function(b){return[b,a.get(b)]})};
m.C=function(a){md(this);var b=0,c=this.j,d=this,e=new ed;e.h=function(){if(c!=d.j)throw Error("The map has changed since the iterator was created");if(b>=d.h.length)throw dd;var f=d.h[b++];return a?f:d.i[f]};
e.next=e.h.bind(e);return e};
function nd(a,b){return Object.prototype.hasOwnProperty.call(a,b)}
;var pd=function(){if(!B.addEventListener||!Object.defineProperty)return!1;var a=!1,b=Object.defineProperty({},"passive",{get:function(){a=!0}});
try{B.addEventListener("test",Da,b),B.removeEventListener("test",Da,b)}catch(c){}return a}();function qd(a,b){this.type=a;this.h=this.target=b;this.defaultPrevented=this.j=!1}
qd.prototype.stopPropagation=function(){this.j=!0};
qd.prototype.preventDefault=function(){this.defaultPrevented=!0};function rd(a,b){qd.call(this,a?a.type:"");this.relatedTarget=this.h=this.target=null;this.button=this.screenY=this.screenX=this.clientY=this.clientX=0;this.key="";this.charCode=this.keyCode=0;this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1;this.state=null;this.pointerId=0;this.pointerType="";this.i=null;a&&this.init(a,b)}
G(rd,qd);var sd={2:"touch",3:"pen",4:"mouse"};
rd.prototype.init=function(a,b){var c=this.type=a.type,d=a.changedTouches&&a.changedTouches.length?a.changedTouches[0]:null;this.target=a.target||a.srcElement;this.h=b;if(b=a.relatedTarget){if(Mb){a:{try{Ib(b.nodeName);var e=!0;break a}catch(f){}e=!1}e||(b=null)}}else"mouseover"==c?b=a.fromElement:"mouseout"==c&&(b=a.toElement);this.relatedTarget=b;d?(this.clientX=void 0!==d.clientX?d.clientX:d.pageX,this.clientY=void 0!==d.clientY?d.clientY:d.pageY,this.screenX=d.screenX||0,this.screenY=d.screenY||
0):(this.clientX=void 0!==a.clientX?a.clientX:a.pageX,this.clientY=void 0!==a.clientY?a.clientY:a.pageY,this.screenX=a.screenX||0,this.screenY=a.screenY||0);this.button=a.button;this.keyCode=a.keyCode||0;this.key=a.key||"";this.charCode=a.charCode||("keypress"==c?a.keyCode:0);this.ctrlKey=a.ctrlKey;this.altKey=a.altKey;this.shiftKey=a.shiftKey;this.metaKey=a.metaKey;this.pointerId=a.pointerId||0;this.pointerType="string"===typeof a.pointerType?a.pointerType:sd[a.pointerType]||"";this.state=a.state;
this.i=a;a.defaultPrevented&&rd.G.preventDefault.call(this)};
rd.prototype.stopPropagation=function(){rd.G.stopPropagation.call(this);this.i.stopPropagation?this.i.stopPropagation():this.i.cancelBubble=!0};
rd.prototype.preventDefault=function(){rd.G.preventDefault.call(this);var a=this.i;a.preventDefault?a.preventDefault():a.returnValue=!1};var td="closure_listenable_"+(1E6*Math.random()|0);var ud=0;function vd(a,b,c,d,e){this.listener=a;this.h=null;this.src=b;this.type=c;this.capture=!!d;this.ba=e;this.key=++ud;this.S=this.W=!1}
function wd(a){a.S=!0;a.listener=null;a.h=null;a.src=null;a.ba=null}
;function xd(a){this.src=a;this.listeners={};this.h=0}
xd.prototype.add=function(a,b,c,d,e){var f=a.toString();a=this.listeners[f];a||(a=this.listeners[f]=[],this.h++);var g=yd(a,b,d,e);-1<g?(b=a[g],c||(b.W=!1)):(b=new vd(b,this.src,f,!!d,e),b.W=c,a.push(b));return b};
xd.prototype.remove=function(a,b,c,d){a=a.toString();if(!(a in this.listeners))return!1;var e=this.listeners[a];b=yd(e,b,c,d);return-1<b?(wd(e[b]),Array.prototype.splice.call(e,b,1),0==e.length&&(delete this.listeners[a],this.h--),!0):!1};
function zd(a,b){var c=b.type;c in a.listeners&&Sa(a.listeners[c],b)&&(wd(b),0==a.listeners[c].length&&(delete a.listeners[c],a.h--))}
function yd(a,b,c,d){for(var e=0;e<a.length;++e){var f=a[e];if(!f.S&&f.listener==b&&f.capture==!!c&&f.ba==d)return e}return-1}
;var Ad="closure_lm_"+(1E6*Math.random()|0),Bd={},Cd=0;function Dd(a,b,c,d,e){if(d&&d.once)Ed(a,b,c,d,e);else if(Array.isArray(b))for(var f=0;f<b.length;f++)Dd(a,b[f],c,d,e);else c=Fd(c),a&&a[td]?a.da(b,c,D(d)?!!d.capture:!!d,e):Gd(a,b,c,!1,d,e)}
function Gd(a,b,c,d,e,f){if(!b)throw Error("Invalid event type");var g=D(e)?!!e.capture:!!e,h=Hd(a);h||(a[Ad]=h=new xd(a));c=h.add(b,c,d,g,f);if(!c.h){d=Id();c.h=d;d.src=a;d.listener=c;if(a.addEventListener)pd||(e=g),void 0===e&&(e=!1),a.addEventListener(b.toString(),d,e);else if(a.attachEvent)a.attachEvent(Jd(b.toString()),d);else if(a.addListener&&a.removeListener)a.addListener(d);else throw Error("addEventListener and attachEvent are unavailable.");Cd++}}
function Id(){function a(c){return b.call(a.src,a.listener,c)}
var b=Kd;return a}
function Ed(a,b,c,d,e){if(Array.isArray(b))for(var f=0;f<b.length;f++)Ed(a,b[f],c,d,e);else c=Fd(c),a&&a[td]?a.i.add(String(b),c,!0,D(d)?!!d.capture:!!d,e):Gd(a,b,c,!0,d,e)}
function Ld(a,b,c,d,e){if(Array.isArray(b))for(var f=0;f<b.length;f++)Ld(a,b[f],c,d,e);else(d=D(d)?!!d.capture:!!d,c=Fd(c),a&&a[td])?a.i.remove(String(b),c,d,e):a&&(a=Hd(a))&&(b=a.listeners[b.toString()],a=-1,b&&(a=yd(b,c,d,e)),(c=-1<a?b[a]:null)&&Md(c))}
function Md(a){if("number"!==typeof a&&a&&!a.S){var b=a.src;if(b&&b[td])zd(b.i,a);else{var c=a.type,d=a.h;b.removeEventListener?b.removeEventListener(c,d,a.capture):b.detachEvent?b.detachEvent(Jd(c),d):b.addListener&&b.removeListener&&b.removeListener(d);Cd--;(c=Hd(b))?(zd(c,a),0==c.h&&(c.src=null,b[Ad]=null)):wd(a)}}}
function Jd(a){return a in Bd?Bd[a]:Bd[a]="on"+a}
function Kd(a,b){if(a.S)a=!0;else{b=new rd(b,this);var c=a.listener,d=a.ba||a.src;a.W&&Md(a);a=c.call(d,b)}return a}
function Hd(a){a=a[Ad];return a instanceof xd?a:null}
var Nd="__closure_events_fn_"+(1E9*Math.random()>>>0);function Fd(a){if("function"===typeof a)return a;a[Nd]||(a[Nd]=function(b){return a.handleEvent(b)});
return a[Nd]}
;function L(){cd.call(this);this.i=new xd(this);this.fa=this;this.M=null}
G(L,cd);L.prototype[td]=!0;L.prototype.addEventListener=function(a,b,c,d){Dd(this,a,b,c,d)};
L.prototype.removeEventListener=function(a,b,c,d){Ld(this,a,b,c,d)};
function M(a,b){var c=a.M;if(c){var d=[];for(var e=1;c;c=c.M)d.push(c),++e}a=a.fa;c=b.type||b;"string"===typeof b?b=new qd(b,a):b instanceof qd?b.target=b.target||a:(e=b,b=new qd(c,a),bb(b,e));e=!0;if(d)for(var f=d.length-1;!b.j&&0<=f;f--){var g=b.h=d[f];e=Od(g,c,!0,b)&&e}b.j||(g=b.h=a,e=Od(g,c,!0,b)&&e,b.j||(e=Od(g,c,!1,b)&&e));if(d)for(f=0;!b.j&&f<d.length;f++)g=b.h=d[f],e=Od(g,c,!1,b)&&e}
L.prototype.R=function(){L.G.R.call(this);if(this.i){var a=this.i,b=0,c;for(c in a.listeners){for(var d=a.listeners[c],e=0;e<d.length;e++)++b,wd(d[e]);delete a.listeners[c];a.h--}}this.M=null};
L.prototype.da=function(a,b,c,d){return this.i.add(String(a),b,!1,c,d)};
function Od(a,b,c,d){b=a.i.listeners[String(b)];if(!b)return!0;b=b.concat();for(var e=!0,f=0;f<b.length;++f){var g=b[f];if(g&&!g.S&&g.capture==c){var h=g.listener,k=g.ba||g.src;g.W&&zd(a.i,g);e=!1!==h.call(k,d)&&e}}return e&&!d.defaultPrevented}
;var Pd=B.JSON.stringify;function O(a){this.h=0;this.o=void 0;this.l=this.i=this.j=null;this.m=this.u=!1;if(a!=Da)try{var b=this;a.call(void 0,function(c){Qd(b,2,c)},function(c){Qd(b,3,c)})}catch(c){Qd(this,3,c)}}
function Rd(){this.next=this.context=this.onRejected=this.i=this.h=null;this.j=!1}
Rd.prototype.reset=function(){this.context=this.onRejected=this.i=this.h=null;this.j=!1};
var Sd=new Gc(function(){return new Rd},function(a){a.reset()});
function Td(a,b,c){var d=Sd.get();d.i=a;d.onRejected=b;d.context=c;return d}
O.prototype.then=function(a,b,c){return Ud(this,"function"===typeof a?a:null,"function"===typeof b?b:null,c)};
O.prototype.$goog_Thenable=!0;O.prototype.cancel=function(a){if(0==this.h){var b=new Vd(a);Oc(function(){Wd(this,b)},this)}};
function Wd(a,b){if(0==a.h)if(a.j){var c=a.j;if(c.i){for(var d=0,e=null,f=null,g=c.i;g&&(g.j||(d++,g.h==a&&(e=g),!(e&&1<d)));g=g.next)e||(f=g);e&&(0==c.h&&1==d?Wd(c,b):(f?(d=f,d.next==c.l&&(c.l=d),d.next=d.next.next):Xd(c),Yd(c,e,3,b)))}a.j=null}else Qd(a,3,b)}
function Zd(a,b){a.i||2!=a.h&&3!=a.h||$d(a);a.l?a.l.next=b:a.i=b;a.l=b}
function Ud(a,b,c,d){var e=Td(null,null,null);e.h=new O(function(f,g){e.i=b?function(h){try{var k=b.call(d,h);f(k)}catch(l){g(l)}}:f;
e.onRejected=c?function(h){try{var k=c.call(d,h);void 0===k&&h instanceof Vd?g(h):f(k)}catch(l){g(l)}}:g});
e.h.j=a;Zd(a,e);return e.h}
O.prototype.B=function(a){this.h=0;Qd(this,2,a)};
O.prototype.M=function(a){this.h=0;Qd(this,3,a)};
function Qd(a,b,c){if(0==a.h){a===c&&(b=3,c=new TypeError("Promise cannot resolve to itself"));a.h=1;a:{var d=c,e=a.B,f=a.M;if(d instanceof O){Zd(d,Td(e||Da,f||null,a));var g=!0}else{if(d)try{var h=!!d.$goog_Thenable}catch(l){h=!1}else h=!1;if(h)d.then(e,f,a),g=!0;else{if(D(d))try{var k=d.then;if("function"===typeof k){ae(d,k,e,f,a);g=!0;break a}}catch(l){f.call(a,l);g=!0;break a}g=!1}}}g||(a.o=c,a.h=b,a.j=null,$d(a),3!=b||c instanceof Vd||be(a,c))}}
function ae(a,b,c,d,e){function f(k){h||(h=!0,d.call(e,k))}
function g(k){h||(h=!0,c.call(e,k))}
var h=!1;try{b.call(a,g,f)}catch(k){f(k)}}
function $d(a){a.u||(a.u=!0,Oc(a.v,a))}
function Xd(a){var b=null;a.i&&(b=a.i,a.i=b.next,b.next=null);a.i||(a.l=null);return b}
O.prototype.v=function(){for(var a;a=Xd(this);)Yd(this,a,this.h,this.o);this.u=!1};
function Yd(a,b,c,d){if(3==c&&b.onRejected&&!b.j)for(;a&&a.m;a=a.j)a.m=!1;if(b.h)b.h.j=null,ce(b,c,d);else try{b.j?b.i.call(b.context):ce(b,c,d)}catch(e){de.call(null,e)}Hc(Sd,b)}
function ce(a,b,c){2==b?a.i.call(a.context,c):a.onRejected&&a.onRejected.call(a.context,c)}
function be(a,b){a.m=!0;Oc(function(){a.m&&de.call(null,b)})}
var de=Kc;function Vd(a){Na.call(this,a)}
G(Vd,Na);Vd.prototype.name="cancel";function P(a){cd.call(this);this.o=1;this.j=[];this.l=0;this.h=[];this.i={};this.v=!!a}
G(P,cd);m=P.prototype;m.subscribe=function(a,b,c){var d=this.i[a];d||(d=this.i[a]=[]);var e=this.o;this.h[e]=a;this.h[e+1]=b;this.h[e+2]=c;this.o=e+3;d.push(e);return e};
function ee(a,b,c){var d=fe;if(a=d.i[a]){var e=d.h;(a=a.find(function(f){return e[f+1]==b&&e[f+2]==c}))&&d.T(a)}}
m.T=function(a){var b=this.h[a];if(b){var c=this.i[b];0!=this.l?(this.j.push(a),this.h[a+1]=Da):(c&&Sa(c,a),delete this.h[a],delete this.h[a+1],delete this.h[a+2])}return!!b};
m.O=function(a,b){var c=this.i[a];if(c){for(var d=Array(arguments.length-1),e=1,f=arguments.length;e<f;e++)d[e-1]=arguments[e];if(this.v)for(e=0;e<c.length;e++){var g=c[e];ge(this.h[g+1],this.h[g+2],d)}else{this.l++;try{for(e=0,f=c.length;e<f;e++)g=c[e],this.h[g+1].apply(this.h[g+2],d)}finally{if(this.l--,0<this.j.length&&0==this.l)for(;c=this.j.pop();)this.T(c)}}return 0!=e}return!1};
function ge(a,b,c){Oc(function(){a.apply(b,c)})}
m.clear=function(a){if(a){var b=this.i[a];b&&(b.forEach(this.T,this),delete this.i[a])}else this.h.length=0,this.i={}};
m.R=function(){P.G.R.call(this);this.clear();this.j.length=0};function he(a){this.h=a}
he.prototype.set=function(a,b){void 0===b?this.h.remove(a):this.h.set(a,Pd(b))};
he.prototype.get=function(a){try{var b=this.h.get(a)}catch(c){return}if(null!==b)try{return JSON.parse(b)}catch(c){throw"Storage: Invalid value was encountered";}};
he.prototype.remove=function(a){this.h.remove(a)};function ie(a){this.h=a}
G(ie,he);function je(a){this.data=a}
function ke(a){return void 0===a||a instanceof je?a:new je(a)}
ie.prototype.set=function(a,b){ie.G.set.call(this,a,ke(b))};
ie.prototype.i=function(a){a=ie.G.get.call(this,a);if(void 0===a||a instanceof Object)return a;throw"Storage: Invalid value was encountered";};
ie.prototype.get=function(a){if(a=this.i(a)){if(a=a.data,void 0===a)throw"Storage: Invalid value was encountered";}else a=void 0;return a};function le(a){this.h=a}
G(le,ie);le.prototype.set=function(a,b,c){if(b=ke(b)){if(c){if(c<Date.now()){le.prototype.remove.call(this,a);return}b.expiration=c}b.creation=Date.now()}le.G.set.call(this,a,b)};
le.prototype.i=function(a){var b=le.G.i.call(this,a);if(b){var c=b.creation,d=b.expiration;if(d&&d<Date.now()||c&&c>Date.now())le.prototype.remove.call(this,a);else return b}};function me(){}
;function ne(){}
G(ne,me);ne.prototype[Symbol.iterator]=function(){return fd(this.C(!0)).i()};
ne.prototype.clear=function(){var a=Array.from(this);a=u(a);for(var b=a.next();!b.done;b=a.next())this.remove(b.value)};function oe(a){this.h=a}
G(oe,ne);m=oe.prototype;m.isAvailable=function(){if(!this.h)return!1;try{return this.h.setItem("__sak","1"),this.h.removeItem("__sak"),!0}catch(a){return!1}};
m.set=function(a,b){try{this.h.setItem(a,b)}catch(c){if(0==this.h.length)throw"Storage mechanism: Storage disabled";throw"Storage mechanism: Quota exceeded";}};
m.get=function(a){a=this.h.getItem(a);if("string"!==typeof a&&null!==a)throw"Storage mechanism: Invalid value was encountered";return a};
m.remove=function(a){this.h.removeItem(a)};
m.C=function(a){var b=0,c=this.h,d=new ed;d.h=function(){if(b>=c.length)throw dd;var e=c.key(b++);if(a)return e;e=c.getItem(e);if("string"!==typeof e)throw"Storage mechanism: Invalid value was encountered";return e};
d.next=d.h.bind(d);return d};
m.clear=function(){this.h.clear()};
m.key=function(a){return this.h.key(a)};function pe(){var a=null;try{a=window.localStorage||null}catch(b){}this.h=a}
G(pe,oe);function qe(a,b){this.i=a;this.h=null;if(Kb&&!(9<=Number(Wb))){re||(re=new kd);this.h=re.get(a);this.h||(b?this.h=document.getElementById(b):(this.h=document.createElement("userdata"),this.h.addBehavior("#default#userData"),document.body.appendChild(this.h)),re.set(a,this.h));try{this.h.load(this.i)}catch(c){this.h=null}}}
G(qe,ne);var se={".":".2E","!":".21","~":".7E","*":".2A","'":".27","(":".28",")":".29","%":"."},re=null;function te(a){return"_"+encodeURIComponent(a).replace(/[.!~*'()%]/g,function(b){return se[b]})}
m=qe.prototype;m.isAvailable=function(){return!!this.h};
m.set=function(a,b){this.h.setAttribute(te(a),b);ue(this)};
m.get=function(a){a=this.h.getAttribute(te(a));if("string"!==typeof a&&null!==a)throw"Storage mechanism: Invalid value was encountered";return a};
m.remove=function(a){this.h.removeAttribute(te(a));ue(this)};
m.C=function(a){var b=0,c=this.h.XMLDocument.documentElement.attributes,d=new ed;d.h=function(){if(b>=c.length)throw dd;var e=c[b++];if(a)return decodeURIComponent(e.nodeName.replace(/\./g,"%")).substr(1);e=e.nodeValue;if("string"!==typeof e)throw"Storage mechanism: Invalid value was encountered";return e};
d.next=d.h.bind(d);return d};
m.clear=function(){for(var a=this.h.XMLDocument.documentElement,b=a.attributes.length;0<b;b--)a.removeAttribute(a.attributes[b-1].nodeName);ue(this)};
function ue(a){try{a.h.save(a.i)}catch(b){throw"Storage mechanism: Quota exceeded";}}
;function ve(a,b){this.i=a;this.h=b+"::"}
G(ve,ne);ve.prototype.set=function(a,b){this.i.set(this.h+a,b)};
ve.prototype.get=function(a){return this.i.get(this.h+a)};
ve.prototype.remove=function(a){this.i.remove(this.h+a)};
ve.prototype.C=function(a){var b=this.i.C(!0),c=this,d=new ed;d.h=function(){for(var e=b.next();e.substr(0,c.h.length)!=c.h;)e=b.next();return a?e.substr(c.h.length):c.i.get(e)};
d.next=d.h.bind(d);return d};var we,xe,ye=B.window,ze=(null===(we=null===ye||void 0===ye?void 0:ye.yt)||void 0===we?void 0:we.config_)||(null===(xe=null===ye||void 0===ye?void 0:ye.ytcfg)||void 0===xe?void 0:xe.data_)||{};E("yt.config_",ze);function Ae(a){for(var b=0;b<arguments.length;++b);b=arguments;1<b.length?ze[b[0]]=b[1]:1===b.length&&Object.assign(ze,b[0])}
function S(a,b){return a in ze?ze[a]:b}
;var Be=[];function Ce(a){Be.forEach(function(b){return b(a)})}
function De(a){return a&&window.yterr?function(){try{return a.apply(this,arguments)}catch(b){Ee(b)}}:a}
function Ee(a){var b=C("yt.logging.errors.log");b?b(a,"ERROR",void 0,void 0,void 0):(b=S("ERRORS",[]),b.push([a,"ERROR",void 0,void 0,void 0]),Ae("ERRORS",b));Ce(a)}
function Fe(a){var b=C("yt.logging.errors.log");b?b(a,"WARNING",void 0,void 0,void 0):(b=S("ERRORS",[]),b.push([a,"WARNING",void 0,void 0,void 0]),Ae("ERRORS",b))}
;var Ge=0;E("ytDomDomGetNextId",C("ytDomDomGetNextId")||function(){return++Ge});var He={stopImmediatePropagation:1,stopPropagation:1,preventMouseEvent:1,preventManipulation:1,preventDefault:1,layerX:1,layerY:1,screenX:1,screenY:1,scale:1,rotation:1,webkitMovementX:1,webkitMovementY:1};
function Ie(a){this.type="";this.state=this.source=this.data=this.currentTarget=this.relatedTarget=this.target=null;this.charCode=this.keyCode=0;this.metaKey=this.shiftKey=this.ctrlKey=this.altKey=!1;this.rotation=this.clientY=this.clientX=0;this.changedTouches=this.touches=null;try{if(a=a||window.event){this.event=a;for(var b in a)b in He||(this[b]=a[b]);this.rotation=a.rotation;var c=a.target||a.srcElement;c&&3==c.nodeType&&(c=c.parentNode);this.target=c;var d=a.relatedTarget;if(d)try{d=d.nodeName?
d:null}catch(e){d=null}else"mouseover"==this.type?d=a.fromElement:"mouseout"==this.type&&(d=a.toElement);this.relatedTarget=d;this.clientX=void 0!=a.clientX?a.clientX:a.pageX;this.clientY=void 0!=a.clientY?a.clientY:a.pageY;this.keyCode=a.keyCode?a.keyCode:a.which;this.charCode=a.charCode||("keypress"==this.type?this.keyCode:0);this.altKey=a.altKey;this.ctrlKey=a.ctrlKey;this.shiftKey=a.shiftKey;this.metaKey=a.metaKey}}catch(e){}}
Ie.prototype.preventDefault=function(){this.event&&(this.event.returnValue=!1,this.event.preventDefault&&this.event.preventDefault())};
Ie.prototype.stopPropagation=function(){this.event&&(this.event.cancelBubble=!0,this.event.stopPropagation&&this.event.stopPropagation())};
Ie.prototype.stopImmediatePropagation=function(){this.event&&(this.event.cancelBubble=!0,this.event.stopImmediatePropagation&&this.event.stopImmediatePropagation())};var Ya=B.ytEventsEventsListeners||{};E("ytEventsEventsListeners",Ya);var Je=B.ytEventsEventsCounter||{count:0};E("ytEventsEventsCounter",Je);
function Ke(a,b,c,d){d=void 0===d?{}:d;a.addEventListener&&("mouseenter"!=b||"onmouseenter"in document?"mouseleave"!=b||"onmouseenter"in document?"mousewheel"==b&&"MozBoxSizing"in document.documentElement.style&&(b="MozMousePixelScroll"):b="mouseout":b="mouseover");return Xa(function(e){var f="boolean"===typeof e[4]&&e[4]==!!d,g=D(e[4])&&D(d)&&Za(e[4],d);return!!e.length&&e[0]==a&&e[1]==b&&e[2]==c&&(f||g)})}
function Le(a){a&&("string"==typeof a&&(a=[a]),H(a,function(b){if(b in Ya){var c=Ya[b],d=c[0],e=c[1],f=c[3];c=c[4];d.removeEventListener?Me()||"boolean"===typeof c?d.removeEventListener(e,f,c):d.removeEventListener(e,f,!!c.capture):d.detachEvent&&d.detachEvent("on"+e,f);delete Ya[b]}}))}
var Me=Pa(function(){var a=!1;try{var b=Object.defineProperty({},"capture",{get:function(){a=!0}});
window.addEventListener("test",null,b)}catch(c){}return a});
function Ne(a,b,c){var d=void 0===d?{}:d;if(a&&(a.addEventListener||a.attachEvent)){var e=Ke(a,b,c,d);if(!e){e=++Je.count+"";var f=!("mouseenter"!=b&&"mouseleave"!=b||!a.addEventListener||"onmouseenter"in document);var g=f?function(h){h=new Ie(h);if(!mc(h.relatedTarget,function(k){return k==a}))return h.currentTarget=a,h.type=b,c.call(a,h)}:function(h){h=new Ie(h);
h.currentTarget=a;return c.call(a,h)};
g=De(g);a.addEventListener?("mouseenter"==b&&f?b="mouseover":"mouseleave"==b&&f?b="mouseout":"mousewheel"==b&&"MozBoxSizing"in document.documentElement.style&&(b="MozMousePixelScroll"),Me()||"boolean"===typeof d?a.addEventListener(b,g,d):a.addEventListener(b,g,!!d.capture)):a.attachEvent("on"+b,g);Ya[e]=[a,b,c,g,d]}}}
;function Oe(a,b){"function"===typeof a&&(a=De(a));return window.setTimeout(a,b)}
function Pe(a){"function"===typeof a&&(a=De(a));return window.setInterval(a,250)}
;var Qe=/^[\w.]*$/,Re={q:!0,search_query:!0};function Se(a,b){b=a.split(b);for(var c={},d=0,e=b.length;d<e;d++){var f=b[d].split("=");if(1==f.length&&f[0]||2==f.length)try{var g=Te(f[0]||""),h=Te(f[1]||"");g in c?Array.isArray(c[g])?Va(c[g],h):c[g]=[c[g],h]:c[g]=h}catch(p){var k=p,l=f[0],n=String(Se);k.args=[{key:l,value:f[1],query:a,method:Ue==n?"unchanged":n}];Re.hasOwnProperty(l)||Fe(k)}}return c}
var Ue=String(Se);function Ve(a){var b=[];Wa(a,function(c,d){var e=encodeURIComponent(String(d)),f;Array.isArray(c)?f=c:f=[c];H(f,function(g){""==g?b.push(e):b.push(e+"="+encodeURIComponent(String(g)))})});
return b.join("&")}
function We(a){"?"==a.charAt(0)&&(a=a.substr(1));return Se(a,"&")}
function Xe(a,b,c){var d=a.split("#",2);a=d[0];d=1<d.length?"#"+d[1]:"";var e=a.split("?",2);a=e[0];e=We(e[1]||"");for(var f in b)!c&&null!==e&&f in e||(e[f]=b[f]);b=a;a=Eb(e);a?(c=b.indexOf("#"),0>c&&(c=b.length),f=b.indexOf("?"),0>f||f>c?(f=c,e=""):e=b.substring(f+1,c),b=[b.substr(0,f),e,b.substr(c)],c=b[1],b[1]=a?c?c+"&"+a:a:c,a=b[0]+(b[1]?"?"+b[1]:"")+b[2]):a=b;return a+d}
function Ye(a){if(!b)var b=window.location.href;var c=a.match(zb)[1]||null,d=Bb(a);c&&d?(a=a.match(zb),b=b.match(zb),a=a[3]==b[3]&&a[1]==b[1]&&a[4]==b[4]):a=d?Bb(b)==d&&(Number(b.match(zb)[4]||null)||null)==(Number(a.match(zb)[4]||null)||null):!0;return a}
function Te(a){return a&&a.match(Qe)?a:decodeURIComponent(a.replace(/\+/g," "))}
;function T(a){a=Ze(a);return"string"===typeof a&&"false"===a?!1:!!a}
function $e(a,b){a=Ze(a);return void 0===a&&void 0!==b?b:Number(a||0)}
function Ze(a){var b=S("EXPERIMENTS_FORCED_FLAGS",{});return void 0!==b[a]?b[a]:S("EXPERIMENT_FLAGS",{})[a]}
;function af(){}
function bf(a,b){return cf(a,0,b)}
function df(a,b){return cf(a,1,b)}
;function ef(){af.apply(this,arguments)}
v(ef,af);function cf(a,b,c){void 0!==c&&Number.isNaN(Number(c))&&(c=void 0);var d=C("yt.scheduler.instance.addJob");return d?d(a,b,c):void 0===c?(a(),NaN):Oe(a,c||0)}
function ff(a){if(void 0===a||!Number.isNaN(Number(a))){var b=C("yt.scheduler.instance.cancelJob");b?b(a):window.clearTimeout(a)}}
ef.prototype.start=function(){var a=C("yt.scheduler.instance.start");a&&a()};ef.h||(ef.h=new ef);function gf(a){var b=hf;a=void 0===a?C("yt.ads.biscotti.lastId_")||"":a;var c=Object,d=c.assign,e={};e.dt=sc;e.flash="0";a:{try{var f=b.h.top.location.href}catch(ya){f=2;break a}f=f?f===b.i.location.href?0:1:2}e=(e.frm=f,e);e.u_tz=-(new Date).getTimezoneOffset();var g=void 0===g?K:g;try{var h=g.history.length}catch(ya){h=0}e.u_his=h;e.u_java=!!K.navigator&&"unknown"!==typeof K.navigator.javaEnabled&&!!K.navigator.javaEnabled&&K.navigator.javaEnabled();K.screen&&(e.u_h=K.screen.height,e.u_w=K.screen.width,
e.u_ah=K.screen.availHeight,e.u_aw=K.screen.availWidth,e.u_cd=K.screen.colorDepth);K.navigator&&K.navigator.plugins&&(e.u_nplug=K.navigator.plugins.length);K.navigator&&K.navigator.mimeTypes&&(e.u_nmime=K.navigator.mimeTypes.length);h=b.h;try{var k=h.screenX;var l=h.screenY}catch(ya){}try{var n=h.outerWidth;var p=h.outerHeight}catch(ya){}try{var r=h.innerWidth;var q=h.innerHeight}catch(ya){}try{var w=h.screenLeft;var A=h.screenTop}catch(ya){}try{r=h.innerWidth,q=h.innerHeight}catch(ya){}try{var z=
h.screen.availWidth;var Q=h.screen.availTop}catch(ya){}k=[w,A,k,l,z,Q,n,p,r,q];l=b.h.top;try{var R=(l||window).document,F="CSS1Compat"==R.compatMode?R.documentElement:R.body;var N=(new gc(F.clientWidth,F.clientHeight)).round()}catch(ya){N=new gc(-12245933,-12245933)}R=N;N={};F=new Ec;B.SVGElement&&B.document.createElementNS&&F.set(0);l=rc();l["allow-top-navigation-by-user-activation"]&&F.set(1);l["allow-popups-to-escape-sandbox"]&&F.set(2);B.crypto&&B.crypto.subtle&&F.set(3);B.TextDecoder&&B.TextEncoder&&
F.set(4);F=Fc(F);N.bc=F;N.bih=R.height;N.biw=R.width;N.brdim=k.join();b=b.i;b=(N.vis={visible:1,hidden:2,prerender:3,preview:4,unloaded:5}[b.visibilityState||b.webkitVisibilityState||b.mozVisibilityState||""]||0,N.wgl=!!K.WebGLRenderingContext,N);c=d.call(c,e,b);c.ca_type="image";a&&(c.bid=a);return c}
var hf=new function(){var a=window.document;this.h=window;this.i=a};
E("yt.ads_.signals_.getAdSignalsString",function(a){return Ve(gf(a))});var jf="XMLHttpRequest"in B?function(){return new XMLHttpRequest}:null;
function kf(){if(!jf)return null;var a=jf();return"open"in a?a:null}
;var lf={Authorization:"AUTHORIZATION","X-Goog-Visitor-Id":"SANDBOXED_VISITOR_ID","X-Youtube-Chrome-Connected":"CHROME_CONNECTED_HEADER","X-YouTube-Client-Name":"INNERTUBE_CONTEXT_CLIENT_NAME","X-YouTube-Client-Version":"INNERTUBE_CONTEXT_CLIENT_VERSION","X-YouTube-Delegation-Context":"INNERTUBE_CONTEXT_SERIALIZED_DELEGATION_CONTEXT","X-YouTube-Device":"DEVICE","X-Youtube-Identity-Token":"ID_TOKEN","X-YouTube-Page-CL":"PAGE_CL","X-YouTube-Page-Label":"PAGE_BUILD_LABEL","X-YouTube-Variants-Checksum":"VARIANTS_CHECKSUM"},
mf="app debugcss debugjs expflag force_ad_params force_ad_encrypted force_viral_ad_response_params forced_experiments innertube_snapshots innertube_goldens internalcountrycode internalipoverride absolute_experiments conditional_experiments sbb sr_bns_address client_dev_root_url client_dev_regex_map".split(" "),nf=!1;
function of(a,b){b=void 0===b?{}:b;var c=Ye(a),d=T("web_ajax_ignore_global_headers_if_set"),e;for(e in lf){var f=S(lf[e]);!f||!c&&Bb(a)||d&&void 0!==b[e]||(b[e]=f)}if(c||!Bb(a))b["X-YouTube-Utc-Offset"]=String(-(new Date).getTimezoneOffset());if(c||!Bb(a)){try{var g=(new Intl.DateTimeFormat).resolvedOptions().timeZone}catch(h){}g&&(b["X-YouTube-Time-Zone"]=g)}if(c||!Bb(a))b["X-YouTube-Ad-Signals"]=Ve(gf(void 0));return b}
function pf(a){var b=window.location.search,c=Bb(a);T("debug_handle_relative_url_for_query_forward_killswitch")||c||!Ye(a)||(c=document.location.hostname);var d=Ab(a.match(zb)[5]||null);d=(c=c&&(c.endsWith("youtube.com")||c.endsWith("youtube-nocookie.com")))&&d&&d.startsWith("/api/");if(!c||d)return a;var e=We(b),f={};H(mf,function(g){e[g]&&(f[g]=e[g])});
return Xe(a,f||{},!1)}
function qf(a,b){var c=b.format||"JSON";a=rf(a,b);var d=sf(a,b),e=!1,f=tf(a,function(k){if(!e){e=!0;h&&window.clearTimeout(h);a:switch(k&&"status"in k?k.status:-1){case 200:case 201:case 202:case 203:case 204:case 205:case 206:case 304:var l=!0;break a;default:l=!1}var n=null,p=400<=k.status&&500>k.status,r=500<=k.status&&600>k.status;if(l||p||r)n=uf(a,c,k,b.convertToSafeHtml);if(l)a:if(k&&204==k.status)l=!0;else{switch(c){case "XML":l=0==parseInt(n&&n.return_code,10);break a;case "RAW":l=!0;break a}l=
!!n}n=n||{};p=b.context||B;l?b.onSuccess&&b.onSuccess.call(p,k,n):b.onError&&b.onError.call(p,k,n);b.onFinish&&b.onFinish.call(p,k,n)}},b.method,d,b.headers,b.responseType,b.withCredentials);
if(b.onTimeout&&0<b.timeout){var g=b.onTimeout;var h=Oe(function(){e||(e=!0,f.abort(),window.clearTimeout(h),g.call(b.context||B,f))},b.timeout)}}
function rf(a,b){b.includeDomain&&(a=document.location.protocol+"//"+document.location.hostname+(document.location.port?":"+document.location.port:"")+a);var c=S("XSRF_FIELD_NAME",void 0);if(b=b.urlParams)b[c]&&delete b[c],a=Xe(a,b||{},!0);return a}
function sf(a,b){var c=S("XSRF_FIELD_NAME",void 0),d=S("XSRF_TOKEN",void 0),e=b.postBody||"",f=b.postParams,g=S("XSRF_FIELD_NAME",void 0),h;b.headers&&(h=b.headers["Content-Type"]);b.excludeXsrf||Bb(a)&&!b.withCredentials&&Bb(a)!=document.location.hostname||"POST"!=b.method||h&&"application/x-www-form-urlencoded"!=h||b.postParams&&b.postParams[g]||(f||(f={}),f[c]=d);f&&"string"===typeof e&&(e=We(e),bb(e,f),e=b.postBodyFormat&&"JSON"==b.postBodyFormat?JSON.stringify(e):Eb(e));if(!(a=e)&&(a=f)){a:{for(var k in f){f=
!1;break a}f=!0}a=!f}!nf&&a&&"POST"!=b.method&&(nf=!0,Ee(Error("AJAX request with postData should use POST")));return e}
function uf(a,b,c,d){var e=null;switch(b){case "JSON":try{var f=c.responseText}catch(g){throw d=Error("Error reading responseText"),d.params=a,Fe(d),g;}a=c.getResponseHeader("Content-Type")||"";f&&0<=a.indexOf("json")&&(")]}'\n"===f.substring(0,5)&&(f=f.substring(5)),e=JSON.parse(f));break;case "XML":if(a=(a=c.responseXML)?vf(a):null)e={},H(a.getElementsByTagName("*"),function(g){e[g.tagName]=wf(g)})}d&&xf(e);
return e}
function xf(a){if(D(a))for(var b in a){var c;(c="html_content"==b)||(c=b.length-5,c=0<=c&&b.indexOf("_html",c)==c);if(c){c=b;var d=xb(a[b],null);a[c]=d}else xf(a[b])}}
function vf(a){return a?(a=("responseXML"in a?a.responseXML:a).getElementsByTagName("root"))&&0<a.length?a[0]:null:null}
function wf(a){var b="";H(a.childNodes,function(c){b+=c.nodeValue});
return b}
function tf(a,b,c,d,e,f,g){function h(){4==(k&&"readyState"in k?k.readyState:0)&&b&&De(b)(k)}
c=void 0===c?"GET":c;d=void 0===d?"":d;var k=kf();if(!k)return null;"onloadend"in k?k.addEventListener("loadend",h,!1):k.onreadystatechange=h;T("debug_forward_web_query_parameters")&&(a=pf(a));k.open(c,a,!0);f&&(k.responseType=f);g&&(k.withCredentials=!0);c="POST"==c&&(void 0===window.FormData||!(d instanceof FormData));if(e=of(a,e))for(var l in e)k.setRequestHeader(l,e[l]),"content-type"==l.toLowerCase()&&(c=!1);c&&k.setRequestHeader("Content-Type","application/x-www-form-urlencoded");k.send(d);
return k}
;var yf=Xb||Yb;function zf(a){var b=sb;return b?0<=b.toLowerCase().indexOf(a):!1}
;var Af={},Bf=0;
function Cf(a,b,c,d,e){e=void 0===e?"":e;if(a)if(c&&!zf("cobalt"))a&&(a instanceof mb||(a="object"==typeof a&&a.ca?a.Z():String(a),qb.test(a)?a=new mb(a,nb):(a=String(a),a=a.replace(/(%0A|%0D)/g,""),a=(b=a.match(pb))&&ob.test(b[1])?new mb(a,nb):null)),a=a||rb,a instanceof mb&&a.constructor===mb?a=a.h:(Ea(a),a="type_error:SafeUrl"),"about:invalid#zClosurez"===a||a.startsWith("data")?a="":(a instanceof vb||(b="object"==typeof a,c=null,b&&a.oa&&(c=a.na()),a=xb(eb(b&&a.ca?a.Z():String(a)),c)),a instanceof
vb&&a.constructor===vb?a=a.h:(Ea(a),a="type_error:SafeHtml"),a=encodeURIComponent(String(Pd(a.toString())))),/^[\s\xa0]*$/.test(a)||(a=jc("IFRAME",{src:'javascript:"<body><img src=\\""+'+a+'+"\\"></body>"',style:"display:none"}),(9==a.nodeType?a:a.ownerDocument||a.document).body.appendChild(a)));else if(e)tf(a,b,"POST",e,d);else if(S("USE_NET_AJAX_FOR_PING_TRANSPORT",!1)||d)tf(a,b,"GET","",d);else{b:{try{var f=new Oa({url:a});if(f.j&&f.i||f.l){var g=Ab(a.match(zb)[5]||null);var h=!(!g||!g.endsWith("/aclk")||
"1"!==Gb(a,"ri"));break b}}catch(k){}h=!1}h?Df(a)?(b&&b(),c=!0):c=!1:c=!1;c||Ef(a,b)}}
function Ff(a,b,c){c=void 0===c?"":c;Df(a,c)?b&&b():Cf(a,b,void 0,void 0,c)}
function Df(a,b){try{if(window.navigator&&window.navigator.sendBeacon&&window.navigator.sendBeacon(a,void 0===b?"":b))return!0}catch(c){}return!1}
function Ef(a,b){var c=new Image,d=""+Bf++;Af[d]=c;c.onload=c.onerror=function(){b&&Af[d]&&b();delete Af[d]};
c.src=a}
;var Gf=B.ytPubsubPubsubInstance||new P,Hf=B.ytPubsubPubsubSubscribedKeys||{},If=B.ytPubsubPubsubTopicToKeys||{},Jf=B.ytPubsubPubsubIsSynchronous||{};P.prototype.subscribe=P.prototype.subscribe;P.prototype.unsubscribeByKey=P.prototype.T;P.prototype.publish=P.prototype.O;P.prototype.clear=P.prototype.clear;E("ytPubsubPubsubInstance",Gf);E("ytPubsubPubsubTopicToKeys",If);E("ytPubsubPubsubIsSynchronous",Jf);E("ytPubsubPubsubSubscribedKeys",Hf);var Kf=window,U=Kf.ytcsi&&Kf.ytcsi.now?Kf.ytcsi.now:Kf.performance&&Kf.performance.timing&&Kf.performance.now&&Kf.performance.timing.navigationStart?function(){return Kf.performance.timing.navigationStart+Kf.performance.now()}:function(){return(new Date).getTime()};var Lf=$e("initial_gel_batch_timeout",2E3),Mf=Math.pow(2,16)-1,Nf=null,Of=0,Pf=void 0,Qf=0,Rf=0,Sf=0,Tf=!0,Uf=B.ytLoggingTransportGELQueue_||new Map;E("ytLoggingTransportGELQueue_",Uf);var Vf=B.ytLoggingTransportTokensToCttTargetIds_||{};E("ytLoggingTransportTokensToCttTargetIds_",Vf);
function Wf(a,b){if("log_event"===a.endpoint){var c="";a.Y?c="visitorOnlyApprovedKey":a.H&&(Vf[a.H.token]=Xf(a.H),c=a.H.token);var d=Uf.get(c)||[];Uf.set(c,d);d.push(a.payload);b&&(Pf=new b);a=$e("tvhtml5_logging_max_batch")||$e("web_logging_max_batch")||100;b=U();d.length>=a?Yf({writeThenSend:!0}):10<=b-Sf&&(Zf(),Sf=b)}}
function $f(a,b){if("log_event"===a.endpoint){var c="";a.Y?c="visitorOnlyApprovedKey":a.H&&(Vf[a.H.token]=Xf(a.H),c=a.H.token);var d=new Map;d.set(c,[a.payload]);b&&(Pf=new b);return new O(function(e){Pf&&Pf.isReady()?ag(d,e,{bypassNetworkless:!0}):e()})}}
function Yf(a){a=void 0===a?{}:a;new O(function(b){window.clearTimeout(Qf);window.clearTimeout(Rf);Rf=0;Pf&&Pf.isReady()?(ag(Uf,b,a),Uf.clear()):(Zf(),b())})}
function Zf(){T("web_gel_timeout_cap")&&!Rf&&(Rf=Oe(function(){Yf({writeThenSend:!0})},6E4));
window.clearTimeout(Qf);var a=S("LOGGING_BATCH_TIMEOUT",$e("web_gel_debounce_ms",1E4));T("shorten_initial_gel_batch_timeout")&&Tf&&(a=Lf);Qf=Oe(function(){Yf({writeThenSend:!0})},a)}
function ag(a,b,c){var d=Pf;c=void 0===c?{}:c;var e=Math.round(U()),f=a.size;a=u(a);for(var g=a.next();!g.done;g=a.next()){var h=u(g.value);g=h.next().value;var k=h.next().value;h=$a({context:bg(d.config_||cg())});h.events=k;(k=Vf[g])&&dg(h,g,k);delete Vf[g];g="visitorOnlyApprovedKey"===g;eg(h,e,g);T("send_beacon_before_gel")&&window.navigator&&window.navigator.sendBeacon&&!c.writeThenSend&&Ff("/generate_204");fg(d,"log_event",h,{retry:!0,onSuccess:function(){f--;f||b();Of=Math.round(U()-e)},
onError:function(){f--;f||b()},
sa:c,Y:g});Tf=!1}}
function eg(a,b,c){a.requestTimeMs=String(b);T("unsplit_gel_payloads_in_logs")&&(a.unsplitGelPayloadsInLogs=!0);!c&&(b=S("EVENT_ID",void 0))&&((c=S("BATCH_CLIENT_COUNTER",void 0)||0)||(c=Math.floor(Math.random()*Mf/2)),c++,c>Mf&&(c=1),Ae("BATCH_CLIENT_COUNTER",c),b={serializedEventId:b,clientCounter:String(c)},a.serializedClientEventId=b,Nf&&Of&&T("log_gel_rtt_web")&&(a.previousBatchInfo={serializedClientEventId:Nf,roundtripMs:String(Of)}),Nf=b,Of=0)}
function dg(a,b,c){if(c.videoId)var d="VIDEO";else if(c.playlistId)d="PLAYLIST";else return;a.credentialTransferTokenTargetId=c;a.context=a.context||{};a.context.user=a.context.user||{};a.context.user.credentialTransferTokens=[{token:b,scope:d}]}
function Xf(a){var b={};a.videoId?b.videoId=a.videoId:a.playlistId&&(b.playlistId=a.playlistId);return b}
;var gg=B.ytLoggingGelSequenceIdObj_||{};E("ytLoggingGelSequenceIdObj_",gg);function hg(){if(!B.matchMedia)return"WEB_DISPLAY_MODE_UNKNOWN";try{return B.matchMedia("(display-mode: standalone)").matches?"WEB_DISPLAY_MODE_STANDALONE":B.matchMedia("(display-mode: minimal-ui)").matches?"WEB_DISPLAY_MODE_MINIMAL_UI":B.matchMedia("(display-mode: fullscreen)").matches?"WEB_DISPLAY_MODE_FULLSCREEN":B.matchMedia("(display-mode: browser)").matches?"WEB_DISPLAY_MODE_BROWSER":"WEB_DISPLAY_MODE_UNKNOWN"}catch(a){return"WEB_DISPLAY_MODE_UNKNOWN"}}
;E("ytglobal.prefsUserPrefsPrefs_",C("ytglobal.prefsUserPrefsPrefs_")||{});var ig={bluetooth:"CONN_DISCO",cellular:"CONN_CELLULAR_UNKNOWN",ethernet:"CONN_WIFI",none:"CONN_NONE",wifi:"CONN_WIFI",wimax:"CONN_CELLULAR_4G",other:"CONN_UNKNOWN",unknown:"CONN_UNKNOWN","slow-2g":"CONN_CELLULAR_2G","2g":"CONN_CELLULAR_2G","3g":"CONN_CELLULAR_3G","4g":"CONN_CELLULAR_4G"},jg={"slow-2g":"EFFECTIVE_CONNECTION_TYPE_SLOW_2G","2g":"EFFECTIVE_CONNECTION_TYPE_2G","3g":"EFFECTIVE_CONNECTION_TYPE_3G","4g":"EFFECTIVE_CONNECTION_TYPE_4G"};
function kg(){var a=B.navigator;return a?a.connection:void 0}
;function lg(){return"INNERTUBE_API_KEY"in ze&&"INNERTUBE_API_VERSION"in ze}
function cg(){return{innertubeApiKey:S("INNERTUBE_API_KEY",void 0),innertubeApiVersion:S("INNERTUBE_API_VERSION",void 0),Ea:S("INNERTUBE_CONTEXT_CLIENT_CONFIG_INFO"),Fa:S("INNERTUBE_CONTEXT_CLIENT_NAME","WEB"),innertubeContextClientVersion:S("INNERTUBE_CONTEXT_CLIENT_VERSION",void 0),Ha:S("INNERTUBE_CONTEXT_HL",void 0),Ga:S("INNERTUBE_CONTEXT_GL",void 0),Ia:S("INNERTUBE_HOST_OVERRIDE",void 0)||"",Ka:!!S("INNERTUBE_USE_THIRD_PARTY_AUTH",!1),Ja:!!S("INNERTUBE_OMIT_API_KEY_WHEN_AUTH_HEADER_IS_PRESENT",
!1),appInstallData:S("SERIALIZED_CLIENT_CONFIG_DATA",void 0)}}
function bg(a){var b={client:{hl:a.Ha,gl:a.Ga,clientName:a.Fa,clientVersion:a.innertubeContextClientVersion,configInfo:a.Ea}};T("web_include_ua_it_context")&&navigator.userAgent&&(b.client.userAgent=String(navigator.userAgent));var c=B.devicePixelRatio;c&&1!=c&&(b.client.screenDensityFloat=String(c));c=S("EXPERIMENTS_TOKEN","");""!==c&&(b.client.experimentsToken=c);c=[];var d=S("EXPERIMENTS_FORCED_FLAGS",{});for(e in d)c.push({key:e,value:String(d[e])});var e=S("EXPERIMENT_FLAGS",{});for(var f in e)f.startsWith("force_")&&
void 0===d[f]&&c.push({key:f,value:String(e[f])});0<c.length&&(b.request={internalExperimentFlags:c});f=b.client.clientName;if("WEB"===f||"MWEB"===f||1===f||2===f){if(!T("web_include_display_mode_killswitch")){var g;b.client.mainAppWebInfo=null!=(g=b.client.mainAppWebInfo)?g:{};b.client.mainAppWebInfo.webDisplayMode=hg()}}else if(g=b.client.clientName,("WEB_REMIX"===g||76===g)&&!T("music_web_display_mode_killswitch")){var h;b.client.ra=null!=(h=b.client.ra)?h:{};b.client.ra.webDisplayMode=hg()}a.appInstallData&&
(b.client.configInfo=b.client.configInfo||{},b.client.configInfo.appInstallData=a.appInstallData);S("DELEGATED_SESSION_ID")&&!T("pageid_as_header_web")&&(b.user={onBehalfOfUser:S("DELEGATED_SESSION_ID")});a:{if(h=kg()){a=ig[h.type||"unknown"]||"CONN_UNKNOWN";h=ig[h.effectiveType||"unknown"]||"CONN_UNKNOWN";"CONN_CELLULAR_UNKNOWN"===a&&"CONN_UNKNOWN"!==h&&(a=h);if("CONN_UNKNOWN"!==a)break a;if("CONN_UNKNOWN"!==h){a=h;break a}}a=void 0}a&&(b.client.connectionType=a);T("web_log_effective_connection_type")&&
(a=kg(),a=null!==a&&void 0!==a&&a.effectiveType?jg.hasOwnProperty(a.effectiveType)?jg[a.effectiveType]:"EFFECTIVE_CONNECTION_TYPE_UNKNOWN":void 0,a&&(b.client.effectiveConnectionType=a));a=Object;h=a.assign;g=b.client;f={};e=u(Object.entries(We(S("DEVICE",""))));for(c=e.next();!c.done;c=e.next())d=u(c.value),c=d.next().value,d=d.next().value,"cbrand"===c?f.deviceMake=d:"cmodel"===c?f.deviceModel=d:"cbr"===c?f.browserName=d:"cbrver"===c?f.browserVersion=d:"cos"===c?f.osName=d:"cosver"===c?f.osVersion=
d:"cplatform"===c&&(f.platform=d);b.client=h.call(a,g,f);return b}
function mg(a,b,c){c=void 0===c?{}:c;var d={"X-Goog-Visitor-Id":c.visitorData||S("VISITOR_DATA","")};if(b&&b.includes("www.youtube-nocookie.com"))return d;(b=c.fb||S("AUTHORIZATION"))||(a?b="Bearer "+C("gapi.auth.getToken")().cb:b=Dc([]));b&&(d.Authorization=b,d["X-Goog-AuthUser"]=S("SESSION_INDEX",0),T("pageid_as_header_web")&&(d["X-Goog-PageId"]=S("DELEGATED_SESSION_ID")));return d}
;function ng(a){a=Object.assign({},a);delete a.Authorization;var b=Dc();if(b){var c=new Xc;c.update(S("INNERTUBE_API_KEY",void 0));c.update(b);b=c.digest();c=3;Fa(b);void 0===c&&(c=0);if(!ac){ac={};for(var d="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""),e=["+/=","+/","-_=","-_.","-_"],f=0;5>f;f++){var g=d.concat(e[f].split(""));$b[f]=g;for(var h=0;h<g.length;h++){var k=g[h];void 0===ac[k]&&(ac[k]=h)}}}c=$b[c];d=Array(Math.floor(b.length/3));e=c[64]||"";for(f=g=0;g<b.length-
2;g+=3){var l=b[g],n=b[g+1];k=b[g+2];h=c[l>>2];l=c[(l&3)<<4|n>>4];n=c[(n&15)<<2|k>>6];k=c[k&63];d[f++]=""+h+l+n+k}h=0;k=e;switch(b.length-g){case 2:h=b[g+1],k=c[(h&15)<<2]||e;case 1:b=b[g],d[f]=""+c[b>>2]+c[(b&3)<<4|h>>4]+k+e}a.hash=d.join("")}return a}
;function og(a){var b=new pe;(b=b.isAvailable()?a?new ve(b,a):b:null)||(a=new qe(a||"UserDataSharedStore"),b=a.isAvailable()?a:null);this.h=(a=b)?new le(a):null;this.i=document.domain||window.location.hostname}
og.prototype.set=function(a,b,c,d){c=c||31104E3;this.remove(a);if(this.h)try{this.h.set(a,b,Date.now()+1E3*c);return}catch(f){}var e="";if(d)try{e=escape(Pd(b))}catch(f){return}else e=escape(b);b=this.i;Ac.set(""+a,e,{ga:c,path:"/",domain:void 0===b?"youtube.com":b,secure:!1})};
og.prototype.get=function(a,b){var c=void 0,d=!this.h;if(!d)try{c=this.h.get(a)}catch(e){d=!0}if(d&&(c=Ac.get(""+a,void 0))&&(c=unescape(c),b))try{c=JSON.parse(c)}catch(e){this.remove(a),c=void 0}return c};
og.prototype.remove=function(a){this.h&&this.h.remove(a);var b=this.i;Ac.remove(""+a,"/",void 0===b?"youtube.com":b)};var pg;function qg(){pg||(pg=new og("yt.innertube"));return pg}
function rg(a,b,c,d){if(d)return null;d=qg().get("nextId",!0)||1;var e=qg().get("requests",!0)||{};e[d]={method:a,request:b,authState:ng(c),requestTime:Math.round(U())};qg().set("nextId",d+1,86400,!0);qg().set("requests",e,86400,!0);return d}
function sg(a){var b=qg().get("requests",!0)||{};delete b[a];qg().set("requests",b,86400,!0)}
function tg(a){var b=qg().get("requests",!0);if(b){for(var c in b){var d=b[c];if(!(6E4>Math.round(U())-d.requestTime)){var e=d.authState,f=ng(mg(!1));Za(e,f)&&(e=d.request,"requestTimeMs"in e&&(e.requestTimeMs=Math.round(U())),fg(a,d.method,e,{}));delete b[c]}}qg().set("requests",b,86400,!0)}}
;var ug=C("ytPubsub2Pubsub2Instance")||new P;P.prototype.subscribe=P.prototype.subscribe;P.prototype.unsubscribeByKey=P.prototype.T;P.prototype.publish=P.prototype.O;P.prototype.clear=P.prototype.clear;E("ytPubsub2Pubsub2Instance",ug);E("ytPubsub2Pubsub2SubscribedKeys",C("ytPubsub2Pubsub2SubscribedKeys")||{});E("ytPubsub2Pubsub2TopicToKeys",C("ytPubsub2Pubsub2TopicToKeys")||{});E("ytPubsub2Pubsub2IsAsync",C("ytPubsub2Pubsub2IsAsync")||{});E("ytPubsub2Pubsub2SkipSubKey",null);function vg(){}
;var wg=function(){var a;return function(){a||(a=new og("ytidb"));return a}}();
function xg(){var a;return null===(a=wg())||void 0===a?void 0:a.get("LAST_RESULT_ENTRY_KEY",!0)}
function yg(a){this.h=void 0===a?!1:a;(a=xg())||(a={hasSucceededOnce:this.h});this.i=a;var b,c;T("ytidb_analyze_is_supported")&&(null===(c=wg())||void 0===c?0:c.h)&&(c={hasSucceededOnce:this.i.hasSucceededOnce||this.h},null===(b=wg())||void 0===b?void 0:b.set("LAST_RESULT_ENTRY_KEY",c,2592E3,!0))}
yg.prototype.isSupported=function(){return this.h};var zg=[],Ag=!1;function Bg(a){Ag||(zg.push({type:"ERROR",payload:a}),10<zg.length&&zg.shift())}
function Cg(a,b){Ag||(zg.push({type:"EVENT",eventType:a,payload:b}),10<zg.length&&zg.shift())}
;function Dg(a,b){for(var c=[],d=1;d<arguments.length;++d)c[d-1]=arguments[d];d=Error.call(this,a);this.message=d.message;"stack"in d&&(this.stack=d.stack);d=[];var e=d.concat;if(!(c instanceof Array)){c=u(c);for(var f,g=[];!(f=c.next()).done;)g.push(f.value);c=g}this.args=e.call(d,c)}
v(Dg,Error);function Eg(){if(void 0!==S("DATASYNC_ID",void 0))return S("DATASYNC_ID",void 0);throw new Dg("Datasync ID not set","unknown");}
;function Fg(a){if(0<=a.indexOf(":"))throw Error("Database name cannot contain ':'");}
function Gg(a){return a.substr(0,a.indexOf(":"))||a}
;var Hg={},Ig=(Hg.AUTH_INVALID="No user identifier specified.",Hg.EXPLICIT_ABORT="Transaction was explicitly aborted.",Hg.IDB_NOT_SUPPORTED="IndexedDB is not supported.",Hg.MISSING_OBJECT_STORE="Object store not created.",Hg.DB_DELETED_BY_MISSING_OBJECT_STORE="Database is deleted because an expected object store was not created.",Hg.UNKNOWN_ABORT="Transaction was aborted for unknown reasons.",Hg.QUOTA_EXCEEDED="The current transaction exceeded its quota limitations.",Hg.QUOTA_MAYBE_EXCEEDED="The current transaction may have failed because of exceeding quota limitations.",
Hg.EXECUTE_TRANSACTION_ON_CLOSED_DB="Can't start a transaction on a closed database",Hg),Jg={},Kg=(Jg.AUTH_INVALID="ERROR",Jg.EXECUTE_TRANSACTION_ON_CLOSED_DB="WARNING",Jg.EXPLICIT_ABORT="IGNORED",Jg.IDB_NOT_SUPPORTED="ERROR",Jg.MISSING_OBJECT_STORE="ERROR",Jg.DB_DELETED_BY_MISSING_OBJECT_STORE="WARNING",Jg.QUOTA_EXCEEDED="WARNING",Jg.QUOTA_MAYBE_EXCEEDED="WARNING",Jg.UNKNOWN_ABORT="WARNING",Jg),Lg={},Mg=(Lg.AUTH_INVALID=!1,Lg.EXECUTE_TRANSACTION_ON_CLOSED_DB=!1,Lg.EXPLICIT_ABORT=!1,Lg.IDB_NOT_SUPPORTED=
!1,Lg.MISSING_OBJECT_STORE=!1,Lg.DB_DELETED_BY_MISSING_OBJECT_STORE=!1,Lg.QUOTA_EXCEEDED=!1,Lg.QUOTA_MAYBE_EXCEEDED=!0,Lg.UNKNOWN_ABORT=!0,Lg);function V(a,b,c,d,e){b=void 0===b?{}:b;c=void 0===c?Ig[a]:c;d=void 0===d?Kg[a]:d;e=void 0===e?Mg[a]:e;Dg.call(this,c,Object.assign({name:"YtIdbKnownError",isSw:void 0===self.document,isIframe:self!==self.top,type:a},b));this.type=a;this.message=c;this.level=d;this.h=e;Object.setPrototypeOf(this,V.prototype)}
v(V,Dg);function Ng(a){V.call(this,"MISSING_OBJECT_STORE",{Ma:a},Ig.MISSING_OBJECT_STORE);Object.setPrototypeOf(this,Ng.prototype)}
v(Ng,V);var Og=["The database connection is closing","Can't start a transaction on a closed database","A mutation operation was attempted on a database that did not allow mutations"];
function Pg(a,b,c){b=Gg(b);var d=a instanceof Error?a:Error("Unexpected error: "+a);if(d instanceof V)return d;if("QuotaExceededError"===d.name)return new V("QUOTA_EXCEEDED",{objectStoreNames:c,dbName:b});if(Zb&&"UnknownError"===d.name)return new V("QUOTA_MAYBE_EXCEEDED",{objectStoreNames:c,dbName:b});if("InvalidStateError"===d.name&&Og.some(function(e){return d.message.includes(e)}))return new V("EXECUTE_TRANSACTION_ON_CLOSED_DB",{objectStoreNames:c,
dbName:b});if("AbortError"===d.name)return new V("UNKNOWN_ABORT",{objectStoreNames:c,dbName:b},d.message);d.args=[{name:"IdbError",kb:d.name,dbName:b,objectStoreNames:c}];d.level="WARNING";return d}
;function Qg(a){if(!a)throw Error();throw a;}
function Rg(a){return a}
function W(a){function b(e){if("PENDING"===d.state.status){d.state={status:"REJECTED",reason:e};e=u(d.onRejected);for(var f=e.next();!f.done;f=e.next())f=f.value,f()}}
function c(e){if("PENDING"===d.state.status){d.state={status:"FULFILLED",value:e};e=u(d.h);for(var f=e.next();!f.done;f=e.next())f=f.value,f()}}
var d=this;this.i=a;this.state={status:"PENDING"};this.h=[];this.onRejected=[];try{this.i(c,b)}catch(e){b(e)}}
W.all=function(a){return new W(function(b,c){var d=[],e=a.length;0===e&&b(d);for(var f={N:0};f.N<a.length;f={N:f.N},++f.N)Sg(W.resolve(a[f.N]).then(function(g){return function(h){d[g.N]=h;e--;0===e&&b(d)}}(f)),function(g){c(g)})})};
W.resolve=function(a){return new W(function(b,c){a instanceof W?a.then(b,c):b(a)})};
W.reject=function(a){return new W(function(b,c){c(a)})};
W.prototype.then=function(a,b){var c=this,d=null!==a&&void 0!==a?a:Rg,e=null!==b&&void 0!==b?b:Qg;return new W(function(f,g){"PENDING"===c.state.status?(c.h.push(function(){Tg(c,c,d,f,g)}),c.onRejected.push(function(){Ug(c,c,e,f,g)})):"FULFILLED"===c.state.status?Tg(c,c,d,f,g):"REJECTED"===c.state.status&&Ug(c,c,e,f,g)})};
function Sg(a,b){a.then(void 0,b)}
function Tg(a,b,c,d,e){try{if("FULFILLED"!==a.state.status)throw Error("calling handleResolve before the promise is fulfilled.");var f=c(a.state.value);f instanceof W?Vg(a,b,f,d,e):d(f)}catch(g){e(g)}}
function Ug(a,b,c,d,e){try{if("REJECTED"!==a.state.status)throw Error("calling handleReject before the promise is rejected.");var f=c(a.state.reason);f instanceof W?Vg(a,b,f,d,e):d(f)}catch(g){e(g)}}
function Vg(a,b,c,d,e){b===c?e(new TypeError("Circular promise chain detected.")):c.then(function(f){f instanceof W?Vg(a,b,f,d,e):d(f)},function(f){e(f)})}
;function Wg(a,b,c){function d(){c(a.error);f()}
function e(){b(a.result);f()}
function f(){try{a.removeEventListener("success",e),a.removeEventListener("error",d)}catch(g){}}
a.addEventListener("success",e);a.addEventListener("error",d)}
function Xg(a){return new Promise(function(b,c){Wg(a,b,c)})}
function X(a){return new W(function(b,c){Wg(a,b,c)})}
;function Yg(a,b){return new W(function(c,d){function e(){var f=a?b(a):null;f?f.then(function(g){a=g;e()},d):c()}
e()})}
;function Zg(a,b){this.h=a;this.options=b;this.transactionCount=0;this.j=Math.round(U());this.i=!1}
m=Zg.prototype;m.add=function(a,b,c){return $g(this,[a],{mode:"readwrite",D:!0},function(d){return ah(d,a).add(b,c)})};
m.clear=function(a){return $g(this,[a],{mode:"readwrite",D:!0},function(b){return ah(b,a).clear()})};
m.close=function(){var a;this.h.close();(null===(a=this.options)||void 0===a?0:a.closed)&&this.options.closed()};
m.count=function(a,b){return $g(this,[a],{mode:"readonly",D:!0},function(c){return ah(c,a).count(b)})};
function bh(a,b,c){a=a.h.createObjectStore(b,c);return new ch(a)}
m.delete=function(a,b){return $g(this,[a],{mode:"readwrite",D:!0},function(c){return ah(c,a).delete(b)})};
m.get=function(a,b){return $g(this,[a],{mode:"readonly",D:!0},function(c){return ah(c,a).get(b)})};
function dh(a,b){return $g(a,["LogsRequestsStore"],{mode:"readwrite",D:!0},function(c){c=ah(c,"LogsRequestsStore");return X(c.h.put(b,void 0))})}
m.objectStoreNames=function(){return Array.from(this.h.objectStoreNames)};
function $g(a,b,c,d){return J(a,function f(){var g=this,h,k,l,n,p,r,q,w,A,z,Q,R;return y(f,function(F){switch(F.h){case 1:var N={mode:"readonly",D:!1,tag:"IDB_TRANSACTION_TAG_UNKNOWN"};"string"===typeof c?N.mode=c:Object.assign(N,c);h=N;g.transactionCount++;k=h.D?$e("ytidb_transaction_try_count",1):1;l=0;case 2:if(n){F.s(3);break}l++;p=Math.round(U());pa(F,4);r=g.h.transaction(b,h.mode);N=new eh(r);N=fh(N,d);return x(F,N,6);case 6:return q=F.i,w=Math.round(U()),gh(g,p,w,l,void 0,b.join(),h),F.return(q);
case 4:A=qa(F);z=Math.round(U());Q=Pg(A,g.h.name,b.join());if((R=Q instanceof V&&!Q.h)||l>=k)gh(g,p,z,l,Q,b.join(),h),n=Q;F.s(2);break;case 3:return F.return(Promise.reject(n))}})})}
function gh(a,b,c,d,e,f,g){b=c-b;e?(e instanceof V&&("QUOTA_EXCEEDED"===e.type||"QUOTA_MAYBE_EXCEEDED"===e.type)&&Cg("QUOTA_EXCEEDED",{dbName:Gg(a.h.name),objectStoreNames:f,transactionCount:a.transactionCount,transactionMode:g.mode}),e instanceof V&&"UNKNOWN_ABORT"===e.type&&(Cg("TRANSACTION_UNEXPECTEDLY_ABORTED",{objectStoreNames:f,transactionDuration:b,transactionCount:a.transactionCount,dbDuration:c-a.j}),a.i=!0),hh(a,!1,d,f,b,g.tag),Bg(e)):hh(a,!0,d,f,b,g.tag)}
function hh(a,b,c,d,e,f){Cg("TRANSACTION_ENDED",{objectStoreNames:d,connectionHasUnknownAbortedTransaction:a.i,duration:e,isSuccessful:b,tryCount:c,tag:void 0===f?"IDB_TRANSACTION_TAG_UNKNOWN":f})}
m.getName=function(){return this.h.name};
function ch(a){this.h=a}
m=ch.prototype;m.add=function(a,b){return X(this.h.add(a,b))};
m.autoIncrement=function(){return this.h.autoIncrement};
m.clear=function(){return X(this.h.clear()).then(function(){})};
m.count=function(a){return X(this.h.count(a))};
function ih(a,b){return jh(a,{query:b},function(c){return c.delete().then(function(){return c.continue()})}).then(function(){})}
m.delete=function(a){return a instanceof IDBKeyRange?ih(this,a):X(this.h.delete(a))};
m.get=function(a){return X(this.h.get(a))};
m.index=function(a){return new kh(this.h.index(a))};
m.getName=function(){return this.h.name};
m.keyPath=function(){return this.h.keyPath};
function jh(a,b,c){a=a.h.openCursor(b.query,b.direction);return lh(a).then(function(d){return Yg(d,c)})}
function eh(a){var b=this;this.h=a;this.j=new Map;this.i=!1;this.done=new Promise(function(c,d){b.h.addEventListener("complete",function(){c()});
b.h.addEventListener("error",function(e){e.currentTarget===e.target&&d(b.h.error)});
b.h.addEventListener("abort",function(){var e=b.h.error;if(e)d(e);else if(!b.i){e=V;for(var f=b.h.objectStoreNames,g=[],h=0;h<f.length;h++){var k=f.item(h);if(null===k)throw Error("Invariant: item in DOMStringList is null");g.push(k)}e=new e("UNKNOWN_ABORT",{objectStoreNames:g.join(),dbName:b.h.db.name,mode:b.h.mode});d(e)}})})}
function fh(a,b){var c=new Promise(function(d,e){try{Sg(b(a).then(function(f){d(f)}),e)}catch(f){e(f),a.abort()}});
return Promise.all([c,a.done]).then(function(d){return u(d).next().value})}
eh.prototype.abort=function(){this.h.abort();this.i=!0;throw new V("EXPLICIT_ABORT");};
function ah(a,b){b=a.h.objectStore(b);var c=a.j.get(b);c||(c=new ch(b),a.j.set(b,c));return c}
function kh(a){this.h=a}
m=kh.prototype;m.count=function(a){return X(this.h.count(a))};
m.delete=function(a){return mh(this,{query:a},function(b){return b.delete().then(function(){return b.continue()})})};
m.get=function(a){return X(this.h.get(a))};
m.getKey=function(a){return X(this.h.getKey(a))};
m.keyPath=function(){return this.h.keyPath};
m.unique=function(){return this.h.unique};
function mh(a,b,c){a=a.h.openCursor(void 0===b.query?null:b.query,void 0===b.direction?"next":b.direction);return lh(a).then(function(d){return Yg(d,c)})}
function nh(a,b){this.request=a;this.cursor=b}
function lh(a){return X(a).then(function(b){return null===b?null:new nh(a,b)})}
m=nh.prototype;m.advance=function(a){this.cursor.advance(a);return lh(this.request)};
m.continue=function(a){this.cursor.continue(a);return lh(this.request)};
m.delete=function(){return X(this.cursor.delete()).then(function(){})};
m.getKey=function(){return this.cursor.key};
m.update=function(a){return X(this.cursor.update(a))};function oh(a,b,c){return new Promise(function(d,e){function f(){r||(r=new Zg(g.result,{closed:p}));return r}
var g=self.indexedDB.open(a,b),h=c.blocked,k=c.blocking,l=c.Pa,n=c.upgrade,p=c.closed,r;g.addEventListener("upgradeneeded",function(q){try{if(null===q.newVersion)throw Error("Invariant: newVersion on IDbVersionChangeEvent is null");if(null===g.transaction)throw Error("Invariant: transaction on IDbOpenDbRequest is null");q.dataLoss&&"none"!==q.dataLoss&&Cg("IDB_DATA_CORRUPTED",{reason:q.dataLossMessage||"unknown reason",dbName:Gg(a)});var w=f(),A=new eh(g.transaction);n&&n(w,q.oldVersion,q.newVersion,
A);A.done.catch(function(z){e(z)})}catch(z){e(z)}});
g.addEventListener("success",function(){var q=g.result;k&&q.addEventListener("versionchange",function(){k(f())});
q.addEventListener("close",function(){Cg("IDB_UNEXPECTEDLY_CLOSED",{dbName:Gg(a),dbVersion:q.version});l&&l()});
d(f())});
g.addEventListener("error",function(){e(g.error)});
h&&g.addEventListener("blocked",function(){h()})})}
function ph(a,b,c){c=void 0===c?{}:c;return oh(a,b,c)}
function qh(a,b){b=void 0===b?{}:b;return J(this,function d(){var e,f,g;return y(d,function(h){e=self.indexedDB.deleteDatabase(a);f=b;(g=f.blocked)&&e.addEventListener("blocked",function(){g()});
return x(h,Xg(e),0)})})}
;function rh(a,b){this.name=a;this.options=b;this.j=!1}
rh.prototype.i=function(a,b,c){c=void 0===c?{}:c;return ph(a,b,c)};
rh.prototype.delete=function(a){a=void 0===a?{}:a;return qh(this.name,a)};
rh.prototype.open=function(){var a=this;if(!this.h){var b,c=function(){a.h===b&&(a.h=void 0)},d={blocking:function(f){f.close()},
closed:c,Pa:c,upgrade:this.options.upgrade},e=function(){return J(a,function g(){var h=this,k,l,n;return y(g,function(p){switch(p.h){case 1:return pa(p,2),x(p,h.i(h.name,h.options.version,d),4);case 4:k=p.i;a:{var r=h.options;for(var q=u(Object.keys(r.ha)),w=q.next();!w.done;w=q.next()){w=w.value;var A=r.ha[w];if("boolean"===typeof A){if(!k.h.objectStoreNames.contains(w)){r=w;break a}}else{var z=void 0===A.Oa?Number.MAX_VALUE:A.Oa;if(k.h.version>=A.eb&&!(k.h.version>=z)&&!k.h.objectStoreNames.contains(w)){r=
w;break a}}}r=void 0}l=r;if(void 0===l){p.s(5);break}if(h.j){p.s(6);break}h.j=!0;return x(p,h.delete(),7);case 7:return Bg(new V("DB_DELETED_BY_MISSING_OBJECT_STORE",{dbName:h.name,Ma:l})),p.return(e());case 6:throw new Ng(l);case 5:return p.return(k);case 2:n=qa(p);if(n instanceof DOMException?"VersionError"===n.name:"DOMError"in self&&n instanceof DOMError?"VersionError"===n.name:n instanceof Object&&"message"in n&&"An attempt was made to open a database using a lower version than the existing version."===
n.message)return p.return(h.i(h.name,void 0,Object.assign(Object.assign({},d),{upgrade:void 0})));c();throw n;}})})};
this.h=b=e()}return this.h};var sh=new rh("YtIdbMeta",{ha:{databases:!0},upgrade:function(a,b){1>b&&bh(a,"databases",{keyPath:"actualName"})}});
function th(a){return J(this,function c(){var d;return y(c,function(e){if(1==e.h)return x(e,sh.open(),2);d=e.i;return e.return($g(d,["databases"],{D:!0,mode:"readwrite"},function(f){var g=ah(f,"databases");return g.get(a.actualName).then(function(h){if(h?a.actualName!==h.actualName||a.publicName!==h.publicName||a.userIdentifier!==h.userIdentifier:1)return X(g.h.put(a,void 0)).then(function(){})})}))})})}
function uh(a){return J(this,function c(){var d;return y(c,function(e){if(1==e.h)return x(e,sh.open(),2);d=e.i;return e.return(d.delete("databases",a))})})}
;var vh;
function wh(){return J(this,function b(){var c,d,e;return y(b,function(f){switch(f.h){case 1:if(T("ytidb_is_supported_cache_success_result")&&(c=xg(),null===c||void 0===c?0:c.hasSucceededOnce))return f.return(new yg(!0));var g;if(g=yf)g=/WebKit\/([0-9]+)/.exec(sb),g=!!(g&&600<=parseInt(g[1],10));g&&(g=/WebKit\/([0-9]+)/.exec(sb),g=!(g&&602<=parseInt(g[1],10)));if(g||Lb)return f.return(new yg(!1));try{if(d=self,!(d.indexedDB&&d.IDBIndex&&d.IDBKeyRange&&d.IDBObjectStore))return f.return(new yg(!1))}catch(h){return f.return(new yg(!1))}if(!("IDBTransaction"in self&&
"objectStoreNames"in IDBTransaction.prototype))return f.return(new yg(!1));pa(f,2);e={actualName:"yt-idb-test-do-not-use",publicName:"yt-idb-test-do-not-use",userIdentifier:void 0};return x(f,th(e),4);case 4:return x(f,uh("yt-idb-test-do-not-use"),5);case 5:return f.return(new yg(!0));case 2:return qa(f),f.return(new yg(!1))}})})}
function xh(){if(void 0!==vh)return vh;Ag=!0;return vh=wh().then(function(a){Ag=!1;return a.isSupported()})}
;function yh(a){try{Eg();var b=!0}catch(c){b=!1}if(!b)throw a=new V("AUTH_INVALID"),Bg(a),a;b=Eg();return{actualName:a+":"+b,publicName:a,userIdentifier:b}}
function zh(a,b,c,d){return J(this,function f(){var g,h;return y(f,function(k){switch(k.h){case 1:return x(k,Ah({caller:"openDbImpl",publicName:a,version:b}),2);case 2:return Fg(a),g=c?{actualName:a,publicName:a,userIdentifier:void 0}:yh(a),pa(k,3),x(k,th(g),5);case 5:return x(k,ph(g.actualName,b,d),6);case 6:return k.return(k.i);case 3:return h=qa(k),pa(k,7),x(k,uh(g.actualName),9);case 9:k.h=8;k.u=0;break;case 7:qa(k);case 8:throw h;}})})}
function Ah(a){return J(this,function c(){var d;return y(c,function(e){if(1==e.h)return x(e,xh(),2);if(!e.i)throw d=new V("IDB_NOT_SUPPORTED",{context:a}),Bg(d),d;e.h=0})})}
function Bh(a,b,c){c=void 0===c?{}:c;return zh(a,b,!1,c)}
function Ch(a,b,c){c=void 0===c?{}:c;return zh(a,b,!0,c)}
function Dh(a,b){b=void 0===b?{}:b;return J(this,function d(){var e;return y(d,function(f){if(1==f.h)return x(f,xh(),2);if(3!=f.h){if(!f.i)return f.return();Fg(a);e=yh(a);return x(f,qh(e.actualName,b),3)}return x(f,uh(e.actualName),0)})})}
function Eh(a,b){b=void 0===b?{}:b;return J(this,function d(){return y(d,function(e){if(1==e.h)return x(e,xh(),2);if(3!=e.h){if(!e.i)return e.return();Fg(a);return x(e,qh(a,b),3)}return x(e,uh(a),0)})})}
;function Fh(){W.call(this,function(){});
throw Error("Not allowed to instantiate the thennable outside of the core library.");}
v(Fh,W);Fh.reject=W.reject;Fh.resolve=W.resolve;Fh.all=W.all;function Gh(a,b){rh.call(this,a,b);this.options=b;Fg(a)}
v(Gh,rh);function Hh(a){var b;return function(){b||(b=new Gh("LogsDatabaseV2",a));return b}}
Gh.prototype.i=function(a,b,c){c=void 0===c?{}:c;return(this.options.wa?Ch:Bh)(a,b,Object.assign({},c))};
Gh.prototype.delete=function(a){a=void 0===a?{}:a;return(this.options.wa?Eh:Dh)(this.name,a)};var Ih;function Jh(){if(Ih)return Ih();var a={};Ih=Hh({ha:(a.LogsRequestsStore=!0,a.sapisid=!0,a.SWHealthLog=!0,a),wa:!1,upgrade:function(b,c,d){2>c&&2<=d&&(bh(b,"LogsRequestsStore",{keyPath:"id",autoIncrement:!0}).h.createIndex("newRequest",["status","authHash","interface","timestamp"],{unique:!1}),bh(b,"sapisid"));3>c&&3<=d&&bh(b,"SWHealthLog",{keyPath:"id",autoIncrement:!0}).h.createIndex("swHealthNewRequest",["interface","timestamp"],{unique:!1})},
version:4});return Ih()}
;function Kh(a){return J(this,function c(){var d,e,f,g,h;return y(c,function(k){switch(k.h){case 1:return d={startTime:U(),transactionType:"YT_IDB_TRANSACTION_TYPE_WRITE"},x(k,Jh().open(),2);case 2:e=k.i;if(5<=e.h.version){f=Object.assign(Object.assign({},a),{options:JSON.parse(JSON.stringify(a.options)),interface:S("INNERTUBE_CONTEXT_CLIENT_NAME",0)});k.s(3);break}return x(k,Lh(),4);case 4:g=k.i,f=Object.assign(Object.assign({},a),{authHash:g,options:JSON.parse(JSON.stringify(a.options)),interface:S("INNERTUBE_CONTEXT_CLIENT_NAME",
0)});case 3:return x(k,dh(e,f),5);case 5:return h=k.i,d.Qa=U(),Mh(d),k.return(h)}})})}
function Nh(){return J(this,function b(){var c,d,e,f,g,h,k,l,n;return y(b,function(p){switch(p.h){case 1:return c={startTime:U(),transactionType:"YT_IDB_TRANSACTION_TYPE_READ"},x(p,Jh().open(),2);case 2:d=p.i;e=S("INNERTUBE_CONTEXT_CLIENT_NAME",0);if(5<=d.h.version){f=["NEW",e,0];g=["NEW",e,U()];p.s(3);break}return x(p,Lh(),4);case 4:h=p.i,f=["NEW",h,e,0],g=["NEW",h,e,U()];case 3:return k=IDBKeyRange.bound(f,g),l=void 0,n=5<=d.h.version?"newRequestV2":"newRequest",x(p,$g(d,["LogsRequestsStore"],{mode:"readwrite",
D:!0},function(r){return mh(ah(r,"LogsRequestsStore").index(n),{query:k,direction:"prev"},function(q){q.cursor.value&&(l=q.cursor.value,l.status="QUEUED",q.update(l))})}),5);
case 5:return c.Qa=U(),Mh(c),p.return(l)}})})}
function Oh(a){return J(this,function c(){var d;return y(c,function(e){if(1==e.h)return x(e,Jh().open(),2);d=e.i;return e.return($g(d,["LogsRequestsStore"],{mode:"readwrite",D:!0},function(f){var g=ah(f,"LogsRequestsStore");return g.get(a).then(function(h){if(h)return h.status="QUEUED",X(g.h.put(h,void 0)).then(function(){return h})})}))})})}
function Ph(a){return J(this,function c(){var d;return y(c,function(e){if(1==e.h)return x(e,Jh().open(),2);d=e.i;return e.return($g(d,["LogsRequestsStore"],{mode:"readwrite",D:!0},function(f){var g=ah(f,"LogsRequestsStore");return g.get(a).then(function(h){return h?(h.status="NEW",h.sendCount+=1,X(g.h.put(h,void 0)).then(function(){return h})):Fh.resolve(void 0)})}))})})}
function Qh(a){return J(this,function c(){var d;return y(c,function(e){if(1==e.h)return x(e,Jh().open(),2);d=e.i;return e.return(d.delete("LogsRequestsStore",a))})})}
function Lh(){return J(this,function b(){var c;return y(b,function(d){if(1==d.h){vg.h||(vg.h=new vg);var e={};var f=Dc([]);f&&(e.Authorization=f,f=void 0,void 0===f&&(f=Number(S("SESSION_INDEX",0)),f=isNaN(f)?0:f),e["X-Goog-AuthUser"]=f,"INNERTUBE_HOST_OVERRIDE"in ze||(e["X-Origin"]=window.location.origin),T("pageid_as_header_web")&&"DELEGATED_SESSION_ID"in ze&&(e["X-Goog-PageId"]=S("DELEGATED_SESSION_ID")));e instanceof O||(f=new O(Da),Qd(f,2,e),e=f);return x(d,e,2)}c=d.i;e=d.return;f=ng(c);var g=
new Xc;g.update(JSON.stringify(f,Object.keys(f).sort()));f=g.digest();g="";for(var h=0;h<f.length;h++)g+="0123456789ABCDEF".charAt(Math.floor(f[h]/16))+"0123456789ABCDEF".charAt(f[h]%16);return e.call(d,g)})})}
function Mh(a){var b=$e("nwl_latency_sampling_rate",.01);!(.02<b)&&Math.random()<=b&&(b=C("ytPubsub2Pubsub2Instance"))&&b.publish.call(b,"nwl_transaction_latency_payload".toString(),"nwl_transaction_latency_payload",a)}
;var Rh;function Sh(){Rh||(Rh=new og("yt.offline"));return Rh}
function Th(a){if(T("offline_error_handling")){var b=Sh().get("errors",!0)||{};b[a.message]={name:a.name,stack:a.stack};a.level&&(b[a.message].level=a.level);Sh().set("errors",b,2592E3,!0)}}
function Uh(){if(T("offline_error_handling")){var a=Sh().get("errors",!0);if(a){for(var b in a)if(a[b]){var c=new Dg(b,"sent via offline_errors");c.name=a[b].name;c.stack=a[b].stack;c.level=a[b].level;Ee(c)}Sh().set("errors",{},2592E3,!0)}}}
;var Vh=$e("network_polling_interval",3E4);function Y(){L.call(this);this.V=0;this.o=this.j=!1;this.v=0;this.l=this.P=!1;this.h=this.aa();this.l=T("validate_network_status");Wh(this);Xh(this)}
v(Y,L);function Yh(){if(!Y.h){var a=C("yt.networkStatusManager.instance")||new Y;E("yt.networkStatusManager.instance",a);Y.h=a}return Y.h}
m=Y.prototype;m.J=function(){this.l||this.h===this.aa()||Fe(new Dg("NetworkStatusManager isOnline does not match window status"));return this.h};
m.Na=function(a){this.j=!0;if(void 0===a?0:a)this.V||Zh(this)};
m.aa=function(){var a=window.navigator.onLine;return void 0===a?!0:a};
m.Ca=function(){this.P=!0};
m.da=function(a,b){return L.prototype.da.call(this,a,b)};
function Xh(a){window.addEventListener("online",function(){return J(a,function c(){var d=this;return y(c,function(e){if(1==e.h)return d.l?x(e,d.L(),2):(d.h=!0,d.j&&M(d,"ytnetworkstatus-online"),e.s(2));$h(d);d.P&&Uh();e.h=0})})})}
function Wh(a){window.addEventListener("offline",function(){return J(a,function c(){var d=this;return y(c,function(e){if(1==e.h)return d.l?x(e,d.L(),2):(d.h=!1,d.j&&M(d,"ytnetworkstatus-offline"),e.s(2));$h(d);e.h=0})})})}
function Zh(a){a.V=bf(function(){return J(a,function c(){var d=this;return y(c,function(e){if(1==e.h){if(T("trigger_nsm_validation_checks_with_nwl")&&!d.h)return x(e,d.L(),3);if(d.aa()){if(!1!==d.h)return e.s(3);d.o=!0;d.v=U();return d.j?d.l?x(e,d.L(),11):(d.h=!0,M(d,"ytnetworkstatus-online"),e.s(11)):e.s(11)}if(!0!==d.h)return e.s(3);d.o=!0;d.v=U();return d.j?d.l?x(e,d.L(),3):(d.h=!1,M(d,"ytnetworkstatus-offline"),e.s(3)):e.s(3)}if(3!=e.h)return d.P&&Uh(),e.s(3);Zh(d);e.h=0})})},Vh)}
function $h(a){a.o&&(Fe(new Dg("NetworkStatusManager state did not match poll",U()-a.v)),a.o=!1)}
m.L=function(a){var b=this;return this.B?this.B:this.B=new Promise(function(c){return J(b,function e(){var f,g,h,k=this;return y(e,function(l){switch(l.h){case 1:return f=window.AbortController?new window.AbortController:void 0,g=null===f||void 0===f?void 0:f.signal,h=!1,pa(l,2,3),f&&(k.U=df(function(){f.abort()},a||2E4)),x(l,fetch("/generate_204",{method:"HEAD",
signal:g}),5);case 5:h=!0;case 3:ra(l);k.B=void 0;k.U&&ff(k.U);h!==k.h&&(k.h=h,k.h&&k.j?M(k,"ytnetworkstatus-online"):k.j&&M(k,"ytnetworkstatus-offline"));c(h);sa(l);break;case 2:qa(l),h=!1,l.s(3)}})})})};
Y.prototype.sendNetworkCheckRequest=Y.prototype.L;Y.prototype.listen=Y.prototype.da;Y.prototype.enableErrorFlushing=Y.prototype.Ca;Y.prototype.getWindowStatus=Y.prototype.aa;Y.prototype.monitorNetworkStatusChange=Y.prototype.Na;Y.prototype.isNetworkAvailable=Y.prototype.J;Y.getInstance=Yh;function ai(a){a=void 0===a?{}:a;L.call(this);var b=this;this.j=this.o=0;this.h=Yh();var c=C("yt.networkStatusManager.instance.monitorNetworkStatusChange").bind(this.h);c&&c(a.Da);a.La&&(c=C("yt.networkStatusManager.instance.enableErrorFlushing").bind(this.h))&&c();if(c=C("yt.networkStatusManager.instance.listen").bind(this.h))a.ea?(this.ea=a.ea,c("ytnetworkstatus-online",function(){bi(b,"publicytnetworkstatus-online")}),c("ytnetworkstatus-offline",function(){bi(b,"publicytnetworkstatus-offline")})):
(c("ytnetworkstatus-online",function(){M(b,"publicytnetworkstatus-online")}),c("ytnetworkstatus-offline",function(){M(b,"publicytnetworkstatus-offline")}))}
v(ai,L);ai.prototype.J=function(){var a=C("yt.networkStatusManager.instance.isNetworkAvailable").bind(this.h);return a?a():!0};
ai.prototype.L=function(a){return J(this,function c(){var d=this,e;return y(c,function(f){return(e=C("yt.networkStatusManager.instance.sendNetworkCheckRequest").bind(d.h))?f.return(e(a)):f.return(!0)})})};
function bi(a,b){a.ea?a.j?(ff(a.o),a.o=df(function(){a.l!==b&&(M(a,b),a.l=b,a.j=U())},a.ea-(U()-a.j))):(M(a,b),a.l=b,a.j=U()):M(a,b)}
;var ci=0,di=0,ei,fi=B.ytNetworklessLoggingInitializationOptions||{isNwlInitialized:!1,isIdbSupported:!1,potentialEsfErrorCounter:di};T("export_networkless_options")&&E("ytNetworklessLoggingInitializationOptions",fi);function gi(a,b){function c(d){var e=hi().J();if(!ii()||!d||e&&T("vss_networkless_bypass_write"))ji(a,b);else{var f={url:a,options:b,timestamp:U(),status:"NEW",sendCount:0};Kh(f).then(function(g){f.id=g;(hi().J()||T("networkless_always_online"))&&ki(f)}).catch(function(g){ki(f);
hi().J()?Ee(g):Th(g)})}}
b=void 0===b?{}:b;T("skip_is_supported_killswitch")?xh().then(function(d){c(d)}):c(li())}
function mi(a,b){function c(d){if(ii()&&d){var e={url:a,options:b,timestamp:U(),status:"NEW",sendCount:0},f=!1,g=b.onSuccess?b.onSuccess:function(){};
e.options.onSuccess=function(h,k){void 0!==e.id?Qh(e.id):f=!0;g(h,k)};
ji(e.url,e.options);Kh(e).then(function(h){e.id=h;f&&Qh(e.id)}).catch(function(h){hi().J()?Ee(h):Th(h)})}else ji(a,b)}
b=void 0===b?{}:b;T("skip_is_supported_killswitch")?xh().then(function(d){c(d)}):c(li())}
function ni(){var a=this;ci||(ci=df(function(){return J(a,function c(){var d;return y(c,function(e){if(1==e.h)return x(e,Nh(),2);if(3!=e.h)return d=e.i,d?x(e,ki(d),3):(ff(ci),ci=0,e.return());if(!T("nwl_throttling_race_fix")||ci)ci=0,ni();e.h=0})})},100))}
function ki(a){return J(this,function c(){var d;return y(c,function(e){switch(e.h){case 1:if(void 0===a.id){e.s(2);break}return x(e,Oh(a.id),3);case 3:(d=e.i)?a=d:Fe(Error("The request cannot be found in the database."));case 2:var f=a.timestamp;if(!(2592E6<=U()-f)){e.s(4);break}Fe(Error("Networkless Logging: Stored logs request expired age limit"));if(void 0===a.id){e.s(5);break}return x(e,Qh(a.id),5);case 5:return e.return();case 4:f=a=oi(a);var g,h;if(null===(h=null===(g=null===f||void 0===f?void 0:
f.options)||void 0===g?void 0:g.postParams)||void 0===h?0:h.requestTimeMs)f.options.postParams.requestTimeMs=Math.round(U());(a=f)&&ji(a.url,a.options);e.h=0}})})}
function oi(a){var b=this,c=a.options.onError?a.options.onError:function(){};
a.options.onError=function(e,f){return J(b,function h(){return y(h,function(k){switch(k.h){case 1:if(!(T("trigger_nsm_validation_checks_with_nwl")&&(C("ytNetworklessLoggingInitializationOptions")?fi.potentialEsfErrorCounter:di)<=$e("potential_esf_error_limit",10))){k.s(2);break}return x(k,hi().L(),3);case 3:if(hi().J())C("ytNetworklessLoggingInitializationOptions")&&fi.potentialEsfErrorCounter++,di++;else return c(e,f),k.return();case 2:if(void 0===(null===a||void 0===a?void 0:a.id)){k.s(4);break}return 1>
a.sendCount?x(k,Ph(a.id),8):x(k,Qh(a.id),4);case 8:df(function(){hi().J()&&ni()},5E3);
case 4:c(e,f),k.h=0}})})};
var d=a.options.onSuccess?a.options.onSuccess:function(){};
a.options.onSuccess=function(e,f){return J(b,function h(){return y(h,function(k){if(1==k.h)return void 0===(null===a||void 0===a?void 0:a.id)?k.s(2):x(k,Qh(a.id),2);d(e,f);k.h=0})})};
return a}
function hi(){ei||(ei=new ai({La:!0,Da:T("trigger_nsm_validation_checks_with_nwl")}));return ei}
function ji(a,b){if(T("networkless_with_beacon")){var c=["method","postBody"];if(Object.keys(b).length>c.length)var d=!0;else{d=0;c=u(c);for(var e=c.next();!e.done;e=c.next())b.hasOwnProperty(e.value)&&d++;d=Object.keys(b).length!==d}d?qf(a,b):T("networkless_with_ping_send")&&1===Object.keys(b).length&&b.allowPingSend?Cf(a):Ff(a,void 0,b.postBody)}else T("networkless_with_ping_send")&&1===Object.keys(b).length&&b.allowPingSend?Cf(a):qf(a,b)}
function ii(){return C("ytNetworklessLoggingInitializationOptions")?fi.isNwlInitialized:!1}
function li(){return C("ytNetworklessLoggingInitializationOptions")?fi.isIdbSupported:!1}
;function pi(a){var b=this;this.config_=null;a?this.config_=a:lg()&&(this.config_=cg());bf(function(){tg(b)},5E3)}
pi.prototype.isReady=function(){!this.config_&&lg()&&(this.config_=cg());return!!this.config_};
function fg(a,b,c,d){function e(r){r=void 0===r?!1:r;var q;if(d.retry&&"www.youtube-nocookie.com"!=h&&(r||(q=rg(b,c,l,k)),q)){var w=g.onSuccess,A=g.onFetchSuccess;g.onSuccess=function(z,Q){sg(q);w(z,Q)};
c.onFetchSuccess=function(z,Q){sg(q);A(z,Q)}}try{r&&d.retry&&!d.sa.bypassNetworkless?(g.method="POST",!d.sa.writeThenSend&&T("nwl_send_fast_on_unload")?mi(p,g):gi(p,g)):(g.method="POST",g.postParams||(g.postParams={}),qf(p,g))}catch(z){if("InvalidAccessError"==z.name)q&&(sg(q),q=0),Fe(Error("An extension is blocking network request."));
else throw z;}q&&bf(function(){tg(a)},5E3)}
!S("VISITOR_DATA")&&"visitor_id"!==b&&.01>Math.random()&&Fe(new Dg("Missing VISITOR_DATA when sending innertube request.",b,c,d));if(!a.isReady()){var f=new Dg("innertube xhrclient not ready",b,c,d);Ee(f);throw f;}var g={headers:{"Content-Type":"application/json"},method:"POST",postParams:c,postBodyFormat:"JSON",onTimeout:function(){d.onTimeout()},
onFetchTimeout:d.onTimeout,onSuccess:function(r,q){if(d.onSuccess)d.onSuccess(q)},
onFetchSuccess:function(r){if(d.onSuccess)d.onSuccess(r)},
onError:function(r,q){if(d.onError)d.onError(q)},
onFetchError:function(r){if(d.onError)d.onError(r)},
timeout:d.timeout,withCredentials:!0},h="";(f=a.config_.Ia)&&(h=f);var k=a.config_.Ka||!1,l=mg(k,h,d);Object.assign(g.headers,l);g.headers.Authorization&&!h&&(g.headers["x-origin"]=window.location.origin);f="/youtubei/"+a.config_.innertubeApiVersion+"/"+b;var n={alt:"json"};a.config_.Ja&&g.headers.Authorization||(n.key=a.config_.innertubeApiKey);var p=Xe(""+h+f,n||{},!0);ii()?xh().then(function(r){e(r)}):e(!1)}
;function qi(a,b){var c=void 0===c?{}:c;var d=pi;S("ytLoggingEventsDefaultDisabled",!1)&&pi==pi&&(d=null);c=void 0===c?{}:c;var e={},f=Math.round(c.timestamp||U());e.eventTimeMs=f<Number.MAX_SAFE_INTEGER?f:0;e[a]=b;a=C("_lact",window);a=null==a?-1:Math.max(Date.now()-a,0);e.context={lastActivityMs:String(c.timestamp||!isFinite(a)?-1:a)};T("log_sequence_info_on_gel_web")&&c.va&&(a=e.context,b=c.va,gg[b]=b in gg?gg[b]+1:0,a.sequence={index:gg[b],groupKey:b},c.hb&&delete gg[c.va]);(c.mb?$f:Wf)({endpoint:"log_event",
payload:e,H:c.H,Y:c.Y},d)}
;var ri=[{qa:function(a){return"Cannot read property '"+a.key+"'"},
ia:{TypeError:[{regexp:/Cannot read property '([^']+)' of (null|undefined)/,groups:["key","value"]},{regexp:/\u65e0\u6cd5\u83b7\u53d6\u672a\u5b9a\u4e49\u6216 (null|undefined) \u5f15\u7528\u7684\u5c5e\u6027\u201c([^\u201d]+)\u201d/,groups:["value","key"]},{regexp:/\uc815\uc758\ub418\uc9c0 \uc54a\uc74c \ub610\ub294 (null|undefined) \ucc38\uc870\uc778 '([^']+)' \uc18d\uc131\uc744 \uac00\uc838\uc62c \uc218 \uc5c6\uc2b5\ub2c8\ub2e4./,groups:["value","key"]},{regexp:/No se puede obtener la propiedad '([^']+)' de referencia nula o sin definir/,
groups:["key"]},{regexp:/Unable to get property '([^']+)' of (undefined or null) reference/,groups:["key","value"]},{regexp:/(null) is not an object \(evaluating '(?:([^.]+)\.)?([^']+)'\)/,groups:["value","base","key"]}],Error:[{regexp:/(Permission denied) to access property "([^']+)"/,groups:["reason","key"]}]}},{qa:function(a){return"Cannot call '"+a.key+"'"},
ia:{TypeError:[{regexp:/(?:([^ ]+)?\.)?([^ ]+) is not a function/,groups:["base","key"]},{regexp:/([^ ]+) called on (null or undefined)/,groups:["key","value"]},{regexp:/Object (.*) has no method '([^ ]+)'/,groups:["base","key"]},{regexp:/Object doesn't support property or method '([^ ]+)'/,groups:["key"]},{regexp:/\u30aa\u30d6\u30b8\u30a7\u30af\u30c8\u306f '([^']+)' \u30d7\u30ed\u30d1\u30c6\u30a3\u307e\u305f\u306f\u30e1\u30bd\u30c3\u30c9\u3092\u30b5\u30dd\u30fc\u30c8\u3057\u3066\u3044\u307e\u305b\u3093/,
groups:["key"]},{regexp:/\uac1c\uccb4\uac00 '([^']+)' \uc18d\uc131\uc774\ub098 \uba54\uc11c\ub4dc\ub97c \uc9c0\uc6d0\ud558\uc9c0 \uc54a\uc2b5\ub2c8\ub2e4./,groups:["key"]}]}}];var ti={K:[],I:[{za:si,weight:500}]};function si(a){a=a.stack;return a.includes("chrome://")||a.includes("chrome-extension://")||a.includes("moz-extension://")}
;function ui(){this.I=[];this.K=[]}
var vi;function wi(){if(!vi){var a=vi=new ui;a.K.length=0;a.I.length=0;ti.K&&a.K.push.apply(a.K,ti.K);ti.I&&a.I.push.apply(a.I,ti.I)}return vi}
;var xi=new P;function yi(a){function b(){return a.charCodeAt(d++)}
var c=a.length,d=0;do{var e=zi(b);if(Infinity===e)break;var f=e>>3;switch(e&7){case 0:e=zi(b);if(2===f)return e;break;case 1:if(2===f)return;d+=8;break;case 2:e=zi(b);if(2===f)return a.substr(d,e);d+=e;break;case 5:if(2===f)return;d+=4;break;default:return}}while(d<c)}
function zi(a){var b=a(),c=b&127;if(128>b)return c;b=a();c|=(b&127)<<7;if(128>b)return c;b=a();c|=(b&127)<<14;if(128>b)return c;b=a();return 128>b?c|(b&127)<<21:Infinity}
;function Ai(a,b,c,d){if(a)if(Array.isArray(a)){var e=d;for(d=0;d<a.length&&!(a[d]&&(e+=Bi(d,a[d],b,c),500<e));d++);d=e}else if("object"===typeof a)for(e in a){if(a[e]){var f=e;var g=a[e],h=b,k=c;f="string"!==typeof g||"clickTrackingParams"!==f&&"trackingParams"!==f?0:(g=yi(atob(g.replace(/-/g,"+").replace(/_/g,"/"))))?Bi(f+".ve",g,h,k):0;d+=f;d+=Bi(e,a[e],b,c);if(500<d)break}}else c[b]=Ci(a),d+=c[b].length;else c[b]=Ci(a),d+=c[b].length;return d}
function Bi(a,b,c,d){c+="."+a;a=Ci(b);d[c]=a;return c.length+a.length}
function Ci(a){return("string"===typeof a?a:String(JSON.stringify(a))).substr(0,500)}
;var Di=new Set,Ei=0,Fi=0,Gi=0,Hi=[],Ii=["PhantomJS","Googlebot","TO STOP THIS SECURITY SCAN go/scan"];var Ji={};function Ki(a){return Ji[a]||(Ji[a]=String(a).replace(/\-([a-z])/g,function(b,c){return c.toUpperCase()}))}
;var Li={},Mi=[],fe=new P,Ni={};function Oi(){for(var a=u(Mi),b=a.next();!b.done;b=a.next())b=b.value,b()}
function Pi(a,b){var c;"yt:"===a.tagName.toLowerCase().substr(0,3)?c=a.getAttribute(b):c=a?a.dataset?a.dataset[Ki(b)]:a.getAttribute("data-"+b):null;return c}
function Qi(a,b){for(var c=1;c<arguments.length;++c);fe.O.apply(fe,arguments)}
;function Ri(a){this.h=!1;this.i=!!window.embedsHttpCleanupKillswitch;this.l=!1;this.j=a||{};this.i?(a=document.getElementById("www-widgetapi-script"),(this.h=!!("https:"===document.location.protocol||a&&0===a.src.indexOf("https:")))&&Si(this)):Si(this)}
function Si(a){a=[a.j,window.YTConfig||{}];for(var b=0;b<a.length;b++)a[b].host&&(a[b].host=a[b].host.toString().replace("http://","https://"))}
function Z(a,b){a=[a.j,window.YTConfig||{}];for(var c=0;c<a.length;c++){var d=a[c][b];if(void 0!==d)return d}return null}
function Ti(a,b,c){Ui||(Ui={},Ne(window,"message",function(d){a:{if(d.origin===Z(a,"host")||a.i&&d.origin===Z(a,"host").toString().replace(/^http:/,"https:")){try{var e=JSON.parse(d.data)}catch(f){e=void 0;break a}a.l=!0;a.i&&!a.h&&0===d.origin.indexOf("https:")&&(a.h=!0);if(d=Ui[e.id])d.o=!0,d.o&&(H(d.u,d.sendMessage,d),d.u.length=0),d.ja(e)}e=void 0}return e}));
Ui[c]=b}
var Ui=null;function Vi(a,b,c){this.m=this.h=this.i=null;this.j=0;this.o=!1;this.u=[];this.l=null;this.B={};if(!a)throw Error("YouTube player element ID required.");this.id=Ga(this);this.v=c;this.setup(a,b)}
m=Vi.prototype;m.setSize=function(a,b){this.h.width=a.toString();this.h.height=b.toString();return this};
m.ya=function(){return this.h};
m.ja=function(a){Wi(this,a.event,a)};
m.addEventListener=function(a,b){var c=b;"string"===typeof b&&(c=function(){window[b].apply(window,arguments)});
if(!c)return this;this.l.subscribe(a,c);Xi(this,a);return this};
function Yi(a,b){b=b.split(".");if(2===b.length){var c=b[1];a.v===b[0]&&Xi(a,c)}}
m.destroy=function(){this.h&&this.h.id&&(Li[this.h.id]=null);var a=this.l;a&&"function"==typeof a.dispose&&a.dispose();if(this.m){a=this.h;var b=a.parentNode;b&&b.replaceChild(this.m,a)}else(a=this.h)&&a.parentNode&&a.parentNode.removeChild(a);Ui&&(Ui[this.id]=null);this.i=null;a=this.h;for(var c in Ya)Ya[c][0]==a&&Le(c);this.m=this.h=null};
m.la=function(){return{}};
function Zi(a,b,c){c=c||[];c=Array.prototype.slice.call(c);b={event:"command",func:b,args:c};a.o?a.sendMessage(b):a.u.push(b)}
function Wi(a,b,c){a.l.m||(c={target:a,data:c},a.l.O(b,c),Qi(a.v+"."+b,c))}
function $i(a,b){var c=document.createElement("iframe");b=b.attributes;for(var d=0,e=b.length;d<e;d++){var f=b[d].value;null!=f&&""!==f&&"null"!==f&&c.setAttribute(b[d].name,f)}c.setAttribute("frameBorder","0");c.setAttribute("allowfullscreen","1");c.setAttribute("allow","accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture");c.setAttribute("title","YouTube "+Z(a.i,"title"));(b=Z(a.i,"width"))&&c.setAttribute("width",b.toString());(b=Z(a.i,"height"))&&c.setAttribute("height",
b.toString());var g=a.la();g.enablejsapi=window.postMessage?1:0;window.location.host&&(g.origin=window.location.protocol+"//"+window.location.host);g.widgetid=a.id;window.location.href&&H(["debugjs","debugcss"],function(h){var k=Gb(window.location.href,h);null!==k&&(g[h]=k)});
window.yt_embedsTokenValue&&(g.embedsTokenValue=encodeURIComponent(window.yt_embedsTokenValue),delete window.yt_embedsTokenValue);c.src=Z(a.i,"host")+("/embed/"+Z(a.i,"videoId"))+"?"+Eb(g);return c}
m.ta=function(){this.h&&this.h.contentWindow?this.sendMessage({event:"listening"}):window.clearInterval(this.j)};
function aj(a){Ti(a.i,a,a.id);a.j=Pe(a.ta.bind(a));Ne(a.h,"load",function(){window.clearInterval(a.j);a.j=Pe(a.ta.bind(a))})}
m.setup=function(a,b){var c=document;if(a="string"===typeof a?c.getElementById(a):a)if(c="iframe"===a.tagName.toLowerCase(),b.host||(b.host=c?Cb(a.src):"https://www.youtube.com"),this.i=new Ri(b),c||(b=$i(this,a),this.m=a,(c=a.parentNode)&&c.replaceChild(b,a),a=b),this.h=a,this.h.id||(this.h.id="widget"+Ga(this.h)),Li[this.h.id]=this,window.postMessage){this.l=new P;aj(this);b=Z(this.i,"events");for(var d in b)b.hasOwnProperty(d)&&this.addEventListener(d,b[d]);for(var e in Ni)Ni.hasOwnProperty(e)&&
Yi(this,e)}};
function Xi(a,b){a.B[b]||(a.B[b]=!0,Zi(a,"addEventListener",[b]))}
m.sendMessage=function(a){a.id=this.id;a.channel="widget";a=Pd(a);var b=this.i;var c=Cb(this.h.src||"");b=b.i?0===c.indexOf("https:")?[c]:b.h?[c.replace("http:","https:")]:b.l?[c]:[c,c.replace("http:","https:")]:[c.replace("http:","https:")];if(this.h.contentWindow)for(c=0;c<b.length;c++)try{this.h.contentWindow.postMessage(a,b[c])}catch(z){if(z.name&&"SyntaxError"===z.name){if(!(z.message&&0<z.message.indexOf("target origin ''"))){var d=void 0,e=z;d=void 0===d?{}:d;d.name=S("INNERTUBE_CONTEXT_CLIENT_NAME",
1);d.version=S("INNERTUBE_CONTEXT_CLIENT_VERSION",void 0);var f=d||{};d="WARNING";d=void 0===d?"ERROR":d;if(e){e.hasOwnProperty("level")&&e.level&&(d=e.level);if(T("console_log_js_exceptions")){var g=e,h=[];h.push("Name: "+g.name);h.push("Message: "+g.message);g.hasOwnProperty("params")&&h.push("Error Params: "+JSON.stringify(g.params));g.hasOwnProperty("args")&&h.push("Error args: "+JSON.stringify(g.args));h.push("File name: "+g.fileName);h.push("Stacktrace: "+g.stack);window.console.log(h.join("\n"),
g)}if(!(5<=Ei)){g=void 0;var k=f,l=Zc(e);f=l.message||"Unknown Error";h=l.name||"UnknownError";var n=l.stack||e.i||"Not available";if(n.startsWith(h+": "+f)){var p=n.split("\n");p.shift();n=p.join("\n")}p=l.lineNumber||"Not available";l=l.fileName||"Not available";var r=0;if(e.hasOwnProperty("args")&&e.args&&e.args.length)for(g=0;g<e.args.length&&!(r=Ai(e.args[g],"params."+g,k,r),500<=r);g++);else if(e.hasOwnProperty("params")&&e.params){var q=e.params;if("object"===typeof e.params)for(g in q){if(q[g]){var w=
"params."+g,A=Ci(q[g]);k[w]=A;r+=w.length+A.length;if(500<r)break}}else k.params=Ci(q)}if(Hi.length)for(g=0;g<Hi.length&&!(r=Ai(Hi[g],"params.context."+g,k,r),500<=r);g++);navigator.vendor&&!k.hasOwnProperty("vendor")&&(k["device.vendor"]=navigator.vendor);g={message:f,name:h,lineNumber:p,fileName:l,stack:n,params:k,sampleWeight:1};f=Number(e.columnNumber);isNaN(f)||(g.lineNumber=g.lineNumber+":"+f);if("IGNORED"===e.level)e=0;else a:{e=wi();f=u(e.K);for(h=f.next();!h.done;h=f.next())if(h=h.value,
g.message&&g.message.match(h.jb)){e=h.weight;break a}e=u(e.I);for(f=e.next();!f.done;f=e.next())if(f=f.value,f.za(g)){e=f.weight;break a}e=1}g.sampleWeight=e;e=g;g=u(ri);for(f=g.next();!f.done;f=g.next())if(f=f.value,f.ia[e.name])for(p=u(f.ia[e.name]),h=p.next();!h.done;h=p.next())if(l=h.value,h=e.message.match(l.regexp)){e.params["params.error.original"]=h[0];p=l.groups;l={};for(n=0;n<p.length;n++)l[p[n]]=h[n+1],e.params["params.error."+p[n]]=h[n+1];e.message=f.qa(l);break}e.params||(e.params={});
g=wi();e.params["params.errorServiceSignature"]="msg="+g.K.length+"&cb="+g.I.length;e.params["params.serviceWorker"]="false";B.document&&B.document.querySelectorAll&&(e.params["params.fscripts"]=String(document.querySelectorAll("script:not([nonce])").length));window.yterr&&"function"===typeof window.yterr&&window.yterr(e);if(0!==e.sampleWeight&&!Di.has(e.message)){"ERROR"===d?(xi.O("handleError",e),T("record_app_crashed_web")&&0===Gi&&1===e.sampleWeight&&(Gi++,qi("appCrashed",{appCrashType:"APP_CRASH_TYPE_BREAKPAD"})),
Fi++):"WARNING"===d&&xi.O("handleWarning",e);if(T("kevlar_gel_error_routing")){g=d;l=e;b:{f=u(Ii);for(h=f.next();!h.done;h=f.next())if(zf(h.value.toLowerCase())){f=!0;break b}f=!1}if(f)f=void 0;else{h={stackTrace:l.stack};l.fileName&&(h.filename=l.fileName);f=l.lineNumber&&l.lineNumber.split?l.lineNumber.split(":"):[];0!==f.length&&(1!==f.length||isNaN(Number(f[0]))?2!==f.length||isNaN(Number(f[0]))||isNaN(Number(f[1]))||(h.lineNumber=Number(f[0]),h.columnNumber=Number(f[1])):h.lineNumber=Number(f[0]));
f={level:"ERROR_LEVEL_UNKNOWN",message:l.message,errorClassName:l.name,sampleWeight:l.sampleWeight};"ERROR"===g?f.level="ERROR_LEVEL_ERROR":"WARNING"===g&&(f.level="ERROR_LEVEL_WARNNING");h={isObfuscated:!0,browserStackInfo:h};p={pageUrl:window.location.href,kvPairs:[]};S("FEXP_EXPERIMENTS")&&(p.experimentIds=S("FEXP_EXPERIMENTS"));if(l=l.params)for(n=u(Object.keys(l)),k=n.next();!k.done;k=n.next())k=k.value,p.kvPairs.push({key:"client."+k,value:String(l[k])});l=S("SERVER_NAME",void 0);n=S("SERVER_VERSION",
void 0);l&&n&&(p.kvPairs.push({key:"server.name",value:l}),p.kvPairs.push({key:"server.version",value:n}));f={errorMetadata:p,stackTrace:h,logMessage:f}}f&&(qi("clientError",f),("ERROR"===g||T("errors_flush_gel_always_killswitch"))&&Yf())}if(!T("suppress_error_204_logging")){f=e;g=f.params||{};d={urlParams:{a:"logerror",t:"jserror",type:f.name,msg:f.message.substr(0,250),line:f.lineNumber,level:d,"client.name":g.name},postParams:{url:S("PAGE_NAME",window.location.href),file:f.fileName},method:"POST"};
g.version&&(d["client.version"]=g.version);if(d.postParams){f.stack&&(d.postParams.stack=f.stack);f=u(Object.keys(g));for(h=f.next();!h.done;h=f.next())h=h.value,d.postParams["client."+h]=g[h];if(g=S("LATEST_ECATCHER_SERVICE_TRACKING_PARAMS",void 0))for(f=u(Object.keys(g)),h=f.next();!h.done;h=f.next())h=h.value,d.postParams[h]=g[h];g=S("SERVER_NAME",void 0);f=S("SERVER_VERSION",void 0);g&&f&&(d.postParams["server.name"]=g,d.postParams["server.version"]=f)}qf(S("ECATCHER_REPORT_HOST","")+"/error_204",
d)}Di.add(e.message);Ei++}}}}}else throw z;}else console&&console.warn&&console.warn("The YouTube player is not attached to the DOM. API calls should be made after the onReady event. See more: https://developers.google.com/youtube/iframe_api_reference#Events")};function bj(a){return(0===a.search("cue")||0===a.search("load"))&&"loadModule"!==a}
function cj(a){return 0===a.search("get")||0===a.search("is")}
;function dj(a,b){Vi.call(this,a,Object.assign({title:"video player",videoId:"",width:640,height:360},b||{}),"player");this.F={};this.playerInfo={}}
v(dj,Vi);m=dj.prototype;m.la=function(){var a=Z(this.i,"playerVars");if(a){var b={},c;for(c in a)b[c]=a[c];a=b}else a={};window!==window.top&&document.referrer&&(a.widget_referrer=document.referrer.substring(0,256));if(c=Z(this.i,"embedConfig")){if(D(c))try{c=JSON.stringify(c)}catch(d){console.error("Invalid embed config JSON",d)}a.embed_config=c}return a};
m.ja=function(a){var b=a.event;a=a.info;switch(b){case "apiInfoDelivery":if(D(a))for(var c in a)a.hasOwnProperty(c)&&(this.F[c]=a[c]);break;case "infoDelivery":ej(this,a);break;case "initialDelivery":D(a)&&(window.clearInterval(this.j),this.playerInfo={},this.F={},fj(this,a.apiInterface),ej(this,a));break;default:Wi(this,b,a)}};
function ej(a,b){if(D(b))for(var c in b)b.hasOwnProperty(c)&&(a.playerInfo[c]=b[c])}
function fj(a,b){H(b,function(c){this[c]||("getCurrentTime"===c?this[c]=function(){var d=this.playerInfo.currentTime;if(1===this.playerInfo.playerState){var e=(Date.now()/1E3-this.playerInfo.currentTimeLastUpdated_)*this.playerInfo.playbackRate;0<e&&(d+=Math.min(e,1))}return d}:bj(c)?this[c]=function(){this.playerInfo={};
this.F={};Zi(this,c,arguments);return this}:cj(c)?this[c]=function(){var d=0;
0===c.search("get")?d=3:0===c.search("is")&&(d=2);return this.playerInfo[c.charAt(d).toLowerCase()+c.substr(d+1)]}:this[c]=function(){Zi(this,c,arguments);
return this})},a)}
m.getVideoEmbedCode=function(){var a=Z(this.i,"host")+("/embed/"+Z(this.i,"videoId")),b=Number(Z(this.i,"width")),c=Number(Z(this.i,"height"));if(isNaN(b)||isNaN(c))throw Error("Invalid width or height property");b=Math.floor(b);c=Math.floor(c);a=yb(a);return'<iframe width="'+b+'" height="'+c+'" src="'+a+'" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>'};
m.getOptions=function(a){return this.F.namespaces?a?this.F[a]?this.F[a].options||[]:[]:this.F.namespaces||[]:[]};
m.getOption=function(a,b){if(this.F.namespaces&&a&&b&&this.F[a])return this.F[a][b]};
function gj(a){if("iframe"!==a.tagName.toLowerCase()){var b=Pi(a,"videoid");b&&(b={videoId:b,width:Pi(a,"width"),height:Pi(a,"height")},new dj(a,b))}}
;E("YT.PlayerState.UNSTARTED",-1);E("YT.PlayerState.ENDED",0);E("YT.PlayerState.PLAYING",1);E("YT.PlayerState.PAUSED",2);E("YT.PlayerState.BUFFERING",3);E("YT.PlayerState.CUED",5);E("YT.get",function(a){return Li[a]});
E("YT.scan",Oi);E("YT.subscribe",function(a,b,c){fe.subscribe(a,b,c);Ni[a]=!0;for(var d in Li)Li.hasOwnProperty(d)&&Yi(Li[d],a)});
E("YT.unsubscribe",function(a,b,c){ee(a,b,c)});
E("YT.Player",dj);Vi.prototype.destroy=Vi.prototype.destroy;Vi.prototype.setSize=Vi.prototype.setSize;Vi.prototype.getIframe=Vi.prototype.ya;Vi.prototype.addEventListener=Vi.prototype.addEventListener;dj.prototype.getVideoEmbedCode=dj.prototype.getVideoEmbedCode;dj.prototype.getOptions=dj.prototype.getOptions;dj.prototype.getOption=dj.prototype.getOption;
Mi.push(function(a){var b=a;b||(b=document);a=Ua(b.getElementsByTagName("yt:player"));var c=b||document;if(c.querySelectorAll&&c.querySelector)b=c.querySelectorAll(".yt-player");else{var d;c=document;b=b||c;if(b.querySelectorAll&&b.querySelector)b=b.querySelectorAll(".yt-player");else if(b.getElementsByClassName){var e=b.getElementsByClassName("yt-player");b=e}else{e=b.getElementsByTagName("*");var f={};for(c=d=0;b=e[c];c++){var g=b.className,h;if(h="function"==typeof g.split)h=0<=Qa(g.split(/\s+/),
"yt-player");h&&(f[d++]=b)}f.length=d;b=f}}b=Ua(b);H(Ta(a,b),gj)});
"undefined"!=typeof YTConfig&&YTConfig.parsetags&&"onload"!=YTConfig.parsetags||Oi();var hj=B.onYTReady;hj&&hj();var ij=B.onYouTubeIframeAPIReady;ij&&ij();var jj=B.onYouTubePlayerAPIReady;jj&&jj();}).call(this);
